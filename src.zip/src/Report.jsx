// Report.jsx
import React, { useEffect, useState } from "react"; // Import React 
import { useNavigate } from "react-router-dom"; // Import navigation
import "./Report.css"; // Import CSS styles

// Function to translate dominant learning style
const translateDominantStyle = (style) => { // Translate style to Arabic with details
  switch (style) { // Check style type
    case 'visual': // Visual learning style
      return {
        title: 'بصري', 
        description: 'أظهر الطفل قدرة على التركيز البصري وتتبع الصور والعناصر المعروضة على الشاشة و تمكن من التمييز بين الأشكال والألوان.', // Visual description
        icon: 'visibility' 
      };
    case 'audio': // Audio learning style
      return {
        title: 'سمعي', 
        description: 'أظهر الطفل قدرة جيدة على متابعة التعليمات السمعية والتمييز بين الأصوات المقدمة في الأنشطة.', // Audio description
        icon: 'hearing' 
      };
    case 'mixed': // Mixed learning style
      return {
        title: 'مختلط', 
        description: 'أظهر الطفل قدرة متوازنة في دمج المثيرات السمعية والبصرية أثناء أداء المهام. تمكن من الاستماع للتعليمات الصوتية وفي الوقت نفسه معالجة العناصر البصرية المطلوبة في النشاط.', // Mixed description
        icon: 'psychology' 
      };
    default: 
      return {
        title: 'غير محدد', 
        description: '', // Empty description
        icon: 'help_outline' 
      };
  }
};

// Function to get game title based on component name
const getGameTitle = (componentName, index) => {
    const titles = { // Game titles object
        'AnimalSoundsMatch': 'لعبة تمييز أصوات الحيوانات', 
        'ColorMatching': 'لعبة تطابق الألوان',
        'SoundMatch': 'لعبة الاستماع و التمييز', 
        'FoodSorting': 'لعبة تصنيف الأطعمة', 
    };
    return titles[componentName] || `اللعبة ${index + 1}`; // Return title or default
};

export default function Report({ childId, gameSummaries = [], finalScores }) { // Report component with props
  const [child, setChild] = useState({}); // State for child data
  const navigate = useNavigate(); // Initialize navigation function
  const [lastServerResult, setLastServerResult] = useState(null); // State for last server result
  const [loadingChild, setLoadingChild] = useState(true); // State for loading status

  // Effect to fetch child data
  useEffect(() => { // Effect runs when childId changes
    if (!childId) { // Check if childId exists
      setLoadingChild(false); // Stop loading if no childId
      return; // Exit effect
    }

    setLoadingChild(true); // Start loading
    fetch(`http://localhost:3001/get-child/${childId}`) // Fetch child data from API
      .then((res) => res.json()) // Parse response as JSON
      .then((data) => { // Handle successful response
        setChild(data || {}); // Update child state with fetched data
      })
      .catch((err) => { // Handle fetch error
        console.error("Fetch child error:", err); // Log error to console
        setChild({}); // Set empty child object
      })
      .finally(() => setLoadingChild(false)); // Stop loading after fetch completes
  }, [childId]); // Re-run when childId changes

  useEffect(() => { // Effect to fetch last result
    if (!childId) return; // Exit if no childId
    
    // Fetch last result from server with new counters
    const timer = setTimeout(() => { // Set timeout for delayed fetch
        fetch(`http://localhost:3001/get-last-result/${childId}`) // Fetch last result from API
          .then((res) => res.json()) // Parse response as JSON
          .then((data) => { // Handle successful response
            if (data.message === "no_results") { // Check if no results found
              setLastServerResult(null); // Set null if no results
            } else {
              setLastServerResult(data.result); // Update with result data
            }
          })
          .catch((err) => { // Handle fetch error
            console.error("Fetch last result error:", err); // Log error to console
          });
    }, 1000); // 1 second delay

    return () => clearTimeout(timer); // Cleanup timer on unmount

  }, [childId]); // Re-run when childId changes

  const correct = (finalScores?.visual_correct ?? 0) + (finalScores?.audio_correct ?? 0); // Calculate total correct answers
  const wrong = (finalScores?.visual_wrong ?? 0) + (finalScores?.audio_wrong ?? 0); // Calculate total wrong answers
  
  // Extract new counters from finalScores
  const skipped = finalScores?.skipped ?? 0; // Get skipped count or default to 0
  const micClicks = finalScores?.mic_clicks ?? 0; // Get mic clicks count or default to 0
  const dragCancels = finalScores?.drag_cancels ?? 0; // Get drag cancels count or default to 0

  const visual = lastServerResult?.visual ?? null; // Get visual score from server result
  const audio = lastServerResult?.audio ?? null; // Get audio score from server result
  const dominantStyle = lastServerResult?.dominant ?? null; // Get dominant style from server result
  

  return (
    <div className="page-container" dir="rtl"> {/* Main container with RTL direction */}
      <div className="content-box"> {/* Content wrapper */}
       {/* Top Bar */}
       <div className="topbar"> {/* Top navigation bar */}
         <div className="topbar-button topbar-spacer"></div> {/* Empty spacer for alignment */}
            <h2 className="title">تقرير النتائج</h2> 
            <div className="topbar-button" onClick={() => navigate(-1)}> {/* Back button wrapper */}
              <span className="material-symbols-outlined back-button"> 
                arrow_back 
              </span>
            </div>
         </div>

        {/* Header */}
        <div className="profile-header"> {/* Profile header section */}
          <div className="child-info"> {/* Child information container */}
            <div
              className="child-img-wrapper" // Child image wrapper
              style={{ // Dynamic inline styles
                backgroundImage: child.image ? `url("${child.image}")` : "none", // Set background image if exists
                backgroundColor: !child.image ? "#eee" : "transparent", // Fallback background color
              }}
            ></div>

            <div className="child-details"> {/* Child details container */}
              <p className="child-name">{child.child_name || "—"}</p> {/* Child name or placeholder */}
              <p className="child-sub">تقرير اختبار الانتباه</p> 
            </div>
          </div>
        </div>

        {/* Stats (updated to include skipped answers) */}
        <div className="stats"> {/* Statistics container */}
         <div className="stat-box"> {/* Correct answers stat */}
            <p className="stat-title">الإجابات الصحيحة</p> 
            <p className="stat-value">{correct}</p> {/* Correct answers count */}
          </div>

          <div className="stat-box"> {/* Wrong answers stat */}
            <p className="stat-title">الإجابات الخاطئة</p> 
            <p className="stat-value">{wrong}</p> {/* Wrong answers count */}
          </div>
          
          <div className="stat-box"> {/* Skipped answers stat */}
            <p className="stat-title">الإجابات المتروكة</p> 
            <p className="stat-value">{skipped}</p> {/* Skipped answers count */}
          </div>
        </div>

       

        {/* Performance */}
        <h3 className="section-title">تحليل الأداء</h3> 

        <div className="progress-section"> {/* Progress section container */}
          <div className="progress-card"> {/* Audio attention card */}
            <div className="progress-row"> {/* Progress header row */}
              <p className="progress-title">الانتباه السمعي</p> 
              <p className="progress-num">{audio ?? "—"}%</p> {/* Audio percentage */}
            </div>
            <div className="progress-bar"> {/* Progress bar container */}
              <div className="progress-fill" style={{ width: `${audio ?? 0}%` }}></div> {/* Progress fill based on audio score */}
            </div>
            <p className="progress-desc">أداء في تمييز الأصوات</p> 
          </div>

          <div className="progress-card"> {/* Visual attention card */}
            <div className="progress-row"> {/* Progress header row */}
              <p className="progress-title">الانتباه البصري</p> 
              <p className="progress-num">{visual ?? "—"}%</p> {/* Visual percentage */}
            </div>
            <div className="progress-bar"> {/* Progress bar container */}
              <div className="progress-fill" style={{ width: `${visual ?? 0}%` }}></div> {/* Progress fill based on visual score */}
            </div>
            <p className="progress-desc">أداء في المتابعة البصرية</p> 
          </div>
        </div>

        {/* Summary */}
        <div className="summary-box"> {/* Summary container */}
          <div className="summary-head"> {/* Summary header */}
            <div className="summary-icon"> {/* Icon wrapper */}
              <span className="material-symbols-outlined"> 
                {translateDominantStyle(dominantStyle)?.icon} {/* Display icon based on dominant style */}
             </span>
            </div>
            <h4 className="summary-title">ملخص الأداء</h4> 
          </div>

          {dominantStyle ? ( // Check if dominant style exists
           <>
             <p className="summary-text"> {/* Summary text */}
               <strong>نمط الانتباه الغالب: </strong> 
               {translateDominantStyle(dominantStyle).title} {/* Display dominant style title */}
             </p>

             <p className="summary-desc"> {/* Summary description */}
               {translateDominantStyle(dominantStyle).description} {/* Display dominant style description */}
             </p>
             </>
          ) : ( // If no dominant style
           <p className="summary-text"> {/* Fallback text */}
               النتائج المعروضة تعتمد على جولات اللعب الحالية. 
             </p>
          )}
        </div>

        {/* Display game summaries */}
        <h3 className="section-title">تفاصيل الأداء لكل لعبة</h3> 

        <div className="answer-list"> {/* Answer list container */}
          {gameSummaries.length > 0 ? ( // Check if game summaries exist
              gameSummaries.map((game, index) => ( // Map through game summaries
                  <div key={index} className="answer-card"> {/* Individual game card */}
                      <div className="answer-left"> {/* Left side of card */}
                          <span className="material-symbols-outlined answer-icon"> {/* Game icon */}
                              {game.type === 'visual' ? 'visibility' : 'hearing'} {/* Icon based on game type */}
                          </span>
                          <div> {/* Game info container */}
                              <p className="answer-title"> {/* Game title */}
                                  {getGameTitle(game.gameName, index)} {/* Display game title */}
                              </p>
                              <p className="answer-time">الوقت المستغرق: {game.durationSeconds} ثانية</p> {/* Display duration */}
                          </div>
                      </div>
                      
                      <div className="answer-status-summary"> {/* Game stats container */}
                          <p className="summary-stat correct-stat">صحيح: {game.correct}</p> {/* Correct count */}
                          <p className="summary-stat wrong-stat">خطأ: {game.wrong}</p> {/* Wrong count */}
                          <p className="summary-stat skipped-stat">متروك: {game.skipped}</p> {/* Skipped count */}

                      </div>
                  </div>
              ))
          ) : ( // If no game summaries
               <p className="no-summary-msg">لم يتم العثور على ملخصات للجولات الحالية.</p> 
          )}
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react'; // Import React for state, effects, callbacks, memoization, and refs
import './SoundMatch.css'; // Import CSS styles


const defaultConfig = { // Default configuration object for game appearance and text
 main_title: "لعبة الاستماع والتمييز", 
 subtitle: "استمع للصوت ثم اختر الصورة المناسبة:", 
 background_color: "#e9d5ff", // Background color 
 surface_color: "#ffffff", // Surface/card color 
 text_color: "#000000", // Text color 
 primary_action_color: "#22c55e", // Primary action color 
 secondary_action_color: "#ef4444", // Secondary action color 
 font_family: "", // Font family 
 font_size: 16 // Base font size in pixels
};

const QUESTION_SOUND = 'SoundMatch'; // Name of the question sound file

const choices = [ // Array of answer choices with their properties
 { value: 'Thunder', label: 'رعد', emoji: '🌩️' }, 
 { value: 'Plane', label: 'طائرة', emoji: '✈️' }, 
 { value: 'Motorcycle', label: 'دراجة نارية', emoji: '🏍️' },
 { value: 'Train', label: 'قطار', emoji: '🚆' }, 
 { value: 'Fire Truck', label: 'سيارة إطفاء', emoji: '🚒' }, 
 { value: 'Telephone', label: 'هاتف', emoji: '📞' } 
];

const stagesData = [ // Array of game stages with sound and correct answer for each stage
 { id: 1, soundToPlay: 'Train', correctAnswer: "Train", label: "المرحلة 1" },
 { id: 2, soundToPlay: 'Plane', correctAnswer: "Plane", label: "المرحلة 2" }, 
 { id: 3, soundToPlay: 'Thunder', correctAnswer: "Thunder", label: "المرحلة 3" }, 
 { id: 4, soundToPlay: 'Fire Truck', correctAnswer: "Fire Truck", label: "المرحلة 4" }, 
 { id: 5, soundToPlay: 'Motorcycle', correctAnswer: "Motorcycle", label: "المرحلة 5" }, 
 { id: 6, soundToPlay: 'Telephone', correctAnswer: "Telephone", label: "المرحلة 6" } 
];

const getStyle = (config, element) => { // Function to generate dynamic styles based on config and element type

 const baseFont = config.font_family || defaultConfig.font_family; // Get font family from config or use default
 const fontStack = baseFont ? `${baseFont}, Arial, sans-serif` : "Arial, sans-serif"; // Create font stack with fallbacks
 const baseSize = Number(config.font_size || defaultConfig.font_size); // Get base font size as number

 switch (element) { // Return appropriate styles based on element type
   case 'body': return { backgroundColor: config.background_color, fontFamily: fontStack, color: config.text_color, fontSize: baseSize + "px" }; // Body styles
   case 'title': return { fontFamily: fontStack, fontSize: (baseSize*1.75) + "px", color: config.text_color }; 
   case 'subtitle': return { fontFamily: fontStack, fontSize: baseSize + "px", color: config.text_color }; 
   case 'card': return { backgroundColor: config.surface_color, color: config.text_color, fontFamily: fontStack, fontSize: (baseSize*0.95) + "px" }; 
   default: return {}; // Return empty object for unknown element types
  }
};

const GAME_DURATION = 45; // Game duration in seconds 

export default function SoundMatch({ onComplete }) { // Main SoundMatch game component with onComplete callback prop
 const config = defaultConfig; // Use default configuration
 const [currentStageIndex, setCurrentStageIndex] = useState(0); // Track current stage index (starts at 0)
 const [correctAttempts, setCorrectAttempts] = useState(0); // Count correct answers
 const [wrongAttempts, setWrongAttempts] = useState(0); // Count wrong answers
 const [gameEnded, setGameEnded] = useState(false); // Track if game has ended

 // New counters
 const [micClicks, setMicClicks] = useState(0); // Count microphone button clicks
 const [skipped, setSkipped] = useState(0);   // Count skipped questions (when time runs out)

 // New states for game start control
 const [gameState, setGameState] = useState('loading'); // Game state: 'loading', 'countdown', 'active', 'completed'
 const [countdown, setCountdown] = useState(3); // Countdown state (3, 2, 1)

 const [timeLeft, setTimeLeft] = useState(GAME_DURATION); // Time remaining in seconds
 const [timerActive, setTimerActive] = useState(false); // Track if timer is active (starts false)
 
 const startTimeRef = useRef(Date.now()); // Store game start time using ref
 const audioRef = useRef(null); // Reference to current audio element
 const totalStages = stagesData.length; // Total number of stages

 // function to get audio file path
 const getAudioPath = (soundName) => `/sounds/${soundName}.mp3`; // Return path to sound file

 // 1. Stop sound function
 const stopSound = useCallback(() => { // Memoized function to stop currently playing audio
   if (audioRef.current) { // Check if audio is playing
     audioRef.current.pause(); // Pause the audio
     audioRef.current.currentTime = 0; // Reset playback to start
     audioRef.current = null; // Clear audio reference
   }
  }, []); 

 // Function to handle timeout 
 const handleTimeout = useCallback(() => { // Memoized function called when time runs out
   setTimerActive(false); // Stop the timer
   setGameEnded(true); // Mark game as ended
   setGameState('completed'); // Update game state to completed
   stopSound(); // Stop any playing audio

   // Calculate skipped questions when time runs out
   const remainingStages = totalStages - currentStageIndex; // Calculate how many stages were not completed
   setSkipped(remainingStages); // Update skipped count

   const durationSeconds = GAME_DURATION; // Use full game duration

   // Send new counters 
   if (onComplete) onComplete({ // Call parent callback with game results
      type: 'audio', // Game type identifier
      correct: correctAttempts, // Number of correct answers
      wrong: wrongAttempts, // Number of wrong answers
      duration_seconds: durationSeconds, // Game duration in seconds
       // Send new counters 
       skipped: remainingStages, // Number of skipped questions 
       mic_clicks: micClicks, // Number of mic button clicks
       drag_cancels: 0, // Drag cancels (not used in this game)
    });
  }, [correctAttempts, wrongAttempts, onComplete, stopSound, totalStages, currentStageIndex, micClicks]); // Dependencies array

  // 1. Play question sound on loading 
  useEffect(() => { // Effect to handle loading state
    if (gameState === 'loading') { // Only run when in loading state
        setTimerActive(false); // Ensure timer is stopped 
        stopSound(); // Stop any previous audio 
        
        const qSound = new Audio(getAudioPath(QUESTION_SOUND)); // Create audio element for question sound
        audioRef.current = qSound; // Store reference
        qSound.play(); // Play the question sound

        // Transition to countdown after question sound ends 
        qSound.onended = () => { // When sound finishes playing
            setGameState('countdown'); // Move to countdown state
            audioRef.current = null; // Clear audio reference
        };
    }
    // Stop sound when component unmounts
    return () => { // Cleanup function
        if (gameState === 'loading' && audioRef.current) { // If still in loading and audio exists
            audioRef.current.pause(); // Pause the audio
        }
    };
  }, [gameState, stopSound]); // Re-run when gameState or stopSound changes

  // 2. Manage countdown
  useEffect(() => { // Effect to handle countdown state
    if (gameState === 'countdown' && countdown > 0) { // While counting down
        const timer = setTimeout(() => { // Set timeout for 1 second
            setCountdown(prev => prev - 1); // Decrease countdown by 1
        }, 1000); // Wait 1 second
        return () => clearTimeout(timer); // Clear timeout on cleanup
    } 
    // After countdown finishes
    else if (gameState === 'countdown' && countdown === 0) { // When countdown reaches 0
        startTimeRef.current = Date.now(); // Record actual game start time
        setGameState('active'); // Change state to active (game starts)
        setTimerActive(true); // Activate the timer 
        
        // Auto-play first stage sound when game actually starts 
        const stage = stagesData[0]; // Get first stage
        const cSound = new Audio(getAudioPath(stage.soundToPlay)); // Create audio for first stage
        audioRef.current = cSound; // Store reference
        cSound.play(); // Play the sound
    }
  }, [gameState, countdown]); // Re-run when gameState or countdown changes

  // Timer logic (Timer useEffect) 
  useEffect(() => { // Effect to manage game timer
   if (!timerActive || timeLeft <= 0) { // If timer inactive or time is up
     if (timeLeft === 0) { // If time has run out
       handleTimeout(); // Handle timeout
      }
      return; // Exit early
    }

    const interval = setInterval(() => { // Set interval to run every second
      setTimeLeft((prevTime) => prevTime - 1); // Decrease time by 1 second
    }, 1000); // Run every 1000ms (1 second)

    return () => clearInterval(interval); // Clear interval on cleanup
  }, [timerActive, timeLeft, handleTimeout]); // Re-run when these values change

  // Function to play sound 
  const playSound = useCallback(() => { // Memoized function to play current stage sound
   if (gameState !== 'active') return; // Prevent playing if game is not active

   setMicClicks(prev => prev + 1); // Increment mic click counter

   stopSound(); // Stop any currently playing sound
   const currentStage = stagesData[currentStageIndex]; // Get current stage data
   if (!currentStage) return; // Exit if no stage found

   const cardAudio = new Audio(getAudioPath(currentStage.soundToPlay)); // Create audio element for stage sound
   audioRef.current = cardAudio; // Store reference
   cardAudio.play(); // Play the sound
   cardAudio.onended = () => audioRef.current = null; // Clear reference when sound ends
  }, [currentStageIndex, stopSound, gameState]); // Dependencies

  // Function to check answer 
  const checkAnswer = useCallback((choice) => { // Memoized function to validate user's answer
   if (gameState !== 'active') return; // Prevent answering if game is not active 
   const currentCorrectAnswer = stagesData[currentStageIndex].correctAnswer; // Get correct answer for current stage
   const isCorrect = choice === currentCorrectAnswer; // Check if user's choice is correct
   stopSound(); // Stop playing audio

   // Update counters
   const newCorrect = correctAttempts + (isCorrect ? 1 : 0); // Increment correct count if answer is correct
   const newWrong = wrongAttempts + (isCorrect ? 0 : 1); // Increment wrong count if answer is incorrect
 
   setCorrectAttempts(newCorrect); // Update correct attempts state
   setWrongAttempts(newWrong); // Update wrong attempts state

   setTimeout(() => { // Wait 500ms before moving to next stage
      const nextStage = currentStageIndex + 1; // Calculate next stage index
      // Pass results when game ends 
      if (nextStage >= totalStages) { // If no more stages (game completed)
       setGameEnded(true); // Mark game as ended
       setTimerActive(false); // Stop timer
       setGameState('completed'); // Update game state to completed 
       const durationSeconds = Math.round((Date.now() - startTimeRef.current) / 1000); // Calculate actual game duration in seconds
        // Send new counters 
       if (onComplete) onComplete({ // Call parent callback with final results
         type: 'audio', // Game type
         correct: newCorrect, // Final correct count
         wrong: newWrong, // Final wrong count
         duration_seconds: durationSeconds, // Actual duration in seconds
           // Send new counters
           skipped: 0, // No skipped questions when all stages completed
           mic_clicks: micClicks, // Total mic clicks
           drag_cancels: 0, // Drag cancels (not applicable)
        });
      } else { // If more stages remain
      setCurrentStageIndex(nextStage); // Move to next stage
      }
    }, 500); // 500ms delay
  }, [currentStageIndex, totalStages, correctAttempts, wrongAttempts, stopSound, onComplete, gameState, micClicks]); // Dependencies

  // Play stage sound when transitioning to new stage 
  useEffect(() => { // Effect to auto-play sound for new stages
   if (currentStageIndex > 0 && gameState === 'active') { // If not first stage and game is active
     stopSound(); // Stop previous audio 
     const stage = stagesData[currentStageIndex]; // Get current stage data
     const cardAudio = new Audio(getAudioPath(stage.soundToPlay)); // Create audio element
     audioRef.current = cardAudio; // Store reference
     cardAudio.play(); // Play the sound
     cardAudio.onended = () => audioRef.current = null; // Clear reference when done
    }
  }, [currentStageIndex, gameState, stopSound]); // Re-run when stage changes

  const ProgressStep = ({ index }) => { // Component to render individual progress step
   let bgColor = 'rgb(209 213 219)'; // Default gray color for incomplete steps
   if (index < currentStageIndex) bgColor = config.primary_action_color; // Green for completed steps
   else if (index === currentStageIndex) bgColor = 'blue'; // Blue for current step
   return <div className="flex-1 h-3 rounded-full transition-colors duration-300" style={{ backgroundColor: bgColor }} />; // Render progress bar segment
  };

  const MemoizedProgress = useMemo(() => ( // Memoized progress bar to prevent unnecessary re-renders
   <div className="flex flex-row-reverse items-center justify-between gap-2"> {/* Container for progress steps */}
   {stagesData.map((_, i) => <ProgressStep key={i} index={i} />)} {/* Render a step for each stage */}
    </div>
  ), [currentStageIndex, config.primary_action_color]); // Re-render only when these change

  return (
   <div className="game-container"> {/* Main game container */}
      <div 
        className="w-full max-w-4xl rounded-3xl shadow-2xl p-6 flex flex-col gap-6" // Styling classes for game card
        style={{ backgroundColor: '#FCFBF3', position: 'relative' }} // Background color and position
      >
        
        {/* Display loading/countdown screen */}
        {(gameState === 'loading' || gameState === 'countdown') && ( // Show only during loading or countdown
            <div className="countdown-display"> {/* Countdown display container */}
                {gameState === 'loading' && ( // Show during loading
                    <span className="loading-message"></span> // Loading message (empty)
                )}
                {gameState === 'countdown' && ( // Show during countdown
                    <span className="countdown-number">{countdown}</span> // Display countdown number
                )}
            </div>
        )}

        <div className="flex items-center justify-between w-full mt-2"> {/* Header row with mic, title, and timer */}
  {/* Mic button on left (clicks are now counted) */}
  <button
    onClick={playSound} // Play sound when clicked
    aria-label="تشغيل صوت المرحلة" 
    disabled={gameState !== 'active'} // Disable button if game is not active 
    className="audio-button-visual w-12 h-12 flex items-center justify-center text-white rounded-full text-2xl shadow-lg transition" // Button styling
    style={{ backgroundColor: '#3b82f6' }} // Blue background color
  >
    🎙️ 
  </button>

 
  <h1 className="text-3xl font-bold text-black text-center flex-1" style={getStyle(config, 'title')}> 
    {config.main_title} {/* Display main title */}
  </h1>

  {/* Timer on right */}
  <div 
    className={`timer-box ${timeLeft <= 5 ? "timer-warning" : ""}`} // Add warning class when time is low
  >
    <span>⏳</span> 
    <span>{timeLeft}</span> {/* Display remaining time */}
  </div>
</div>

        <p className="text-center text-black text-lg" style={getStyle(config, 'subtitle')}> {/* Subtitle paragraph */}
          {config.subtitle} 
        </p>        

        <main className="game-main"> {/* Main game content area */}
        <section className="progress-section"> {/* Progress section */}
          <span style={{ color: config.text_color }}>المرحلة {Math.min(currentStageIndex+1, totalStages)} من {totalStages}</span> {/* Display current stage number */}
          {MemoizedProgress} {/* Render memoized progress bar */}
        </section>

        {!gameEnded && ( // Show cards only if game hasn't ended
          <section className="cards-section"> {/* Cards section */}
            <div className="cards-grid"> {/* Grid container for answer cards */}
             {choices.map(choice => ( // Map through all choices
                <button 
                    key={choice.value} // Unique key for each button
                    onClick={() => checkAnswer(choice.value)} // Check answer when clicked
                    disabled={gameState !== 'active'} // Disable buttons if game is not active
                    className="card-button" // Button styling class
                    style={getStyle(config, 'card')} // Apply card styles
                    aria-label={choice.label}>
                  <span className="card-emoji-wrapper"> {/* Emoji wrapper */}
                    <span>{choice.emoji}</span> {/* Display emoji */}
                  </span>
                  <span className="card-label">{choice.label}</span> {/* Display label text */}
                 </button>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  </div>
 );
}
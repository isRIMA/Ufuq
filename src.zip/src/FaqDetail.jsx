// Import React from react-router-dom for navigation and parameter retrieval
import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './Settings.css'; // Import CSS styles 

// --- FAQ Content Data Structure ---
const faqContent = {
  // Content for 'About Us' section 
  'about-us': {
    title: "من نحن",
    description: "نحن طالبات من جامعة جدة، اجتمعنا بشغف وحب للتعلم لنقدّم هذا المشروع كجزء من رحلة تخرجنا. عملنا معًا بروح الفريق الواحد، لنحوّل الأفكار إلى واقع مفيد وممتع.",
    sections: [
      {
        title: "أعضاء الفريق",
        type: 'list',
        items: [
          'فرح الحربي',
          'فرح مظفر',
          'ريما السلامة',
          'شفا البدري',
          'همس الشيخ',
        ]
      },
      {
        type: 'text',
        content: 'كل فكرة وقرار في هذا المشروع يعكس تعاوننا، طموحنا، وحبنا لما نعمله.'
      }
    ]
  },
  // Content for 'Contact Us' 
  'contact-us': {
    title: "تواصل معنا",
    type: 'contact-cards', // New type for contact info display
    description: "يمكنكم التواصل معنا مباشرةً عبر البريد الإلكتروني لأي استفسارات تتعلق بالمشروع:",
    cards: [
        { name: 'فرح الحربي', email: 'farahalharbi011@gmail.com', icon: 'person', color: '#1E90FF' },
        { name: 'فرح مظفر', email: 'farah.m03@hotmail.com', icon: 'person', color: '#FF6347' },
        { name: 'شفا البدري', email: 'itsshifaahmed@gmail.com', icon: 'person', color: '#4BC970' },
        { name: 'ريما السلامة', email: 'reemaalsalamh@gmail.com', icon: 'person', color: '#FFD100' },
        { name: 'همس الشيخ', email: 'hamesameen1400@gmail.com', icon: 'person', color: '#9932CC' }, 
    ]
  },
  // Simple Q&A content 
  'add-child': { title: "كيف أضيف طفلاً جديداً؟", answer: "يمكنك إضافة طفل جديد عبر الخطوات التالية:\n1. اذهب إلى الشاشة الرئيسية.\n2. اضغط على زر \"+ إضافة طفل جديد\".\n3. قم بملء اسم الطفل، العمر، واختر شخصية رمزية له.\n4. اضغط على \إضافة الطفل\" لإتمام الإضافة." },
  'track-progress': { title: "كيف أتابع تقدم طفلي؟", answer: "تتم متابعة تقدم الطفل عبر واجهة \"سجل الأداء\" و \"تقرير النتائج\":\n1. من شاشة ملفات الأطفال، اختر اسم الطفل واضغط \"عرض التقارير\".\n2. ستجد ملخصاً لأداء الطفل في اختبارات الانتباه ونسبته المئوية في كل منها.\n3. يمكنك استعراض سجل الأداء لرؤية تفاصيل نتائج وتواريخ الاختبارات السابقة." },
  
  // Content for 'Test Types' 
  'test-types': { 
    title: "أنواع الاختبارات المتوفرة",
    type: 'test-cards', 
    description: "يوفر تطبيق \"أُفق\" مجموعة من الاختبارات المصممة لتقييم أنماط الانتباه الأساسية لدى طفلك:",
    cards: [
        {
            icon: 'visibility', 
            color: '#FFD765', 
            title: "اختبارات الانتباه البصري",
            info: "تهدف إلى قياس قدرة الطفل على التركيز والانتباه على المعلومات البصرية مثل الصور، الأشكال، أو الألوان، واكتشاف التفاصيل الدقيقة دون تشتيت.",
        },
        {
            icon: 'hearing',
            color: '#FFD765', 
            title: "اختبارات الانتباه السمعي",
            info: "تقيم قدرة الطفل على التركيز على المعلومات الصوتية، مثل الأصوات أو الكلمات، والتمييز بينها، مع تجاهل المؤثرات الصوتية الأخرى المشتتة.",
        },
    ]
  },
  
  // Content for 'User Guide'
  'user-guide': { 
    title: "دليل استخدام التطبيق",
    type: 'test-cards', 
    description: "تطبيق أُفق مصمم لدعم التعلم التكيفي من خلال تحديد نمط انتباه طفلك.",
    cards: [
        {
            icon: 'how_to_reg', 
            color: '#FFD765', 
            title: "التسجيل",
            info: "أنشئ حساباً وقم بإضافة ملفات أطفالك للبدء في استخدام التطبيق وخدماته.",
        },
        {
            icon: 'quiz',
            color: '#FFD765', 
            title: "التقييم",
            info: "اطلب من طفلك إجراء الاختبارات البصرية والسمعية للحصول على بيانات دقيقة عن نمط انتباهه.",
        },
        {
            icon: 'trending_up',
            color: '#FFD765', 
            title: "المتابعة",
            info: "راقب \"تقرير النتائج\" لمعرفة نقاط قوة وضعف الانتباه وتوجيه طفلك للمهام المناسبة.",
        },
    ]
  },
  // Content for 'Terms and Privacy'
  'terms-privacy': { 
    title: "شروط الخدمة وسياسة الخصوصية", 
    description: `**سياسة الخصوصية لتطبيق أُفق**
تخضع عملية استخدام تطبيق أُفق والشروط والأحكام المتعلقة بالخدمة، بالإضافة إلى سياسة جمع البيانات وتخزينها، للمساءلة ووفق القوانين المحلية.

**الخصوصية**
نلتزم بحماية بياناتك وبيانات أطفالك. تُستخدم نتائج الاختبارات فقط لتحسين تجربة التعلم وتحديد نمط الانتباه، ولا يتم مشاركتها مع أي طرف ثالث.

**البيانات التي نجمعها**
* معلومات الحساب: الاسم والبريد الإلكتروني
* بيانات الطفل: الاسم، العمر لتحسين التقييمات
* نتائج الاختبارات: لتقديم تقارير دقيقة حول أداء الطفل

**استخدام البيانات**
* تحسين تجربة المستخدم وتقديم توصيات مخصصة
* تحليل الأنماط السلوكية لتطوير التطبيق
* التواصل معك بخصوص التحديثات (بموافقتك)

**حقوقك**
يمكنك في أي وقت الوصول إلى بياناتك، تعديلها، حذفها أو سحب موافقتك، مع العلم أن ذلك قد يؤثر على بعض وظائف التطبيق.

**التغييرات**
قد نقوم بتحديث السياسة من وقت لآخر، وسنخطر المستخدمين بالتغييرات الجوهرية عبر البريد الإلكتروني أو إشعار داخل التطبيق
`,
    type: 'long-text-card' // New type to display long-form text within a card
  }
};

// Test Card Component 
const TestCard = ({ title, info, icon, color }) => {
    return (
        <div className="test-card-item">
            {/* Icon container with dynamic background color */}
            <span className="card-icon" style={{ backgroundColor: color }}>
                <span className="material-symbols-outlined">{icon}</span>
            </span>
            {/* Content area for title and description (RTL) */}
            <div className="card-content-rtl">
                <h3 className="card-title">{title}</h3>
                <p className="card-info">{info}</p>
            </div>
        </div>
    );
};

// Contact Card Component 
const ContactCard = ({ name, email }) => {
    return (
        <div className="test-card-item">
            {/* Content area for name and clickable email link */}
            <div className="card-content-rtl contact-content-rtl">
                <h3 className="card-title contact-name">{name}</h3>
                <a href={`mailto:${email}`} className="card-info item-email-link">
                    {email}
                </a>
            </div>
        </div>
    );
};


// Main Content Rendering Component 
const RenderFaqContent = ({ content }) => {
    
    // Logic for 'contact-cards' type
    if (content.type === 'contact-cards') {
        return (
            <div className="detail-content-area">
                {/* Display contact description */}
                <p style={{ fontSize: '1rem', color: '#4b5563', marginBottom: '1.5rem', lineHeight: '1.6' }}>
                    {content.description}
                </p>
                {/* Render ContactCard components */}
                <div className="test-cards-wrapper">
                    {content.cards.map((card, index) => (
                        <ContactCard 
                            key={index}
                            name={card.name}
                            email={card.email}
                            icon={card.icon}
                            color={card.color}
                        />
                    ))}
                </div>
            </div>
        );
    }

    // Logic for 'test-cards' type 
    if (content.type === 'test-cards') {
        return (
            <div className="detail-content-area">
                {/* Display section description */}
                <p style={{ fontSize: '1rem', color: '#4b5563', marginBottom: '1.5rem', lineHeight: '1.6' }}>
                    {content.description}
                </p>
                {/* Render TestCard components */}
                <div className="test-cards-wrapper">
                    {content.cards.map((card, index) => (
                        <TestCard 
                            key={index}
                            title={card.title}
                            info={card.info}
                            icon={card.icon}
                            color={card.color}
                        />
                    ))}
                </div>
            </div>
        );
    }

    // Logic for 'long-text-card' type 
    if (content.type === 'long-text-card') {
        // Split text by lines and filter empty lines
        const textLines = content.description.split('\n').filter(line => line.trim() !== '');

        return (
            <div className="detail-content-area">
                {/* Card wrapper for long text with styling */}
                <div className="long-text-card-wrapper" style={{ 
                    background: '#ffffff', // Set background to pure white
                    borderRadius: '15px',
                    padding: '25px',
                    boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)',
                    lineHeight: '1.7',
                    color: '#333',
                    fontSize: '0.95rem',
                    textAlign: 'right', 
                    direction: 'rtl',   
                }}>
                    {/* Iterate over lines to render titles, list items, or paragraphs */}
                    {textLines.map((line, index) => {
                        const trimmedLine = line.trim();
                        
                        // Logic for bold titles 
                        if (trimmedLine.startsWith('**') && trimmedLine.endsWith('**')) {
                            const titleText = trimmedLine.slice(2, -2).trim(); // Remove **
                            return <h3 key={index} style={{ 
                                marginTop: (index === 0) ? '0' : '1.5rem', 
                                marginBottom: '0.8rem', 
                                color: '#1a202c', 
                                fontSize: '1.1rem', 
                                fontWeight: 'bold' 
                            }}>{titleText}</h3>;
                        } 
                        
                        // Logic for bullet points (starting with *)
                        if (trimmedLine.startsWith('*')) {
                             return <p key={index} style={{ marginBottom: '0.5rem', paddingRight: '1.5rem', position: 'relative' }}>
                                {/* Custom bullet point using position absolute */}
                                <span style={{ position: 'absolute', right: '0', color: '#1a202c' }}>•</span>
                                {trimmedLine.slice(1).trim()} {/* Display text after the star */}
                            </p>;
                        }
                        
                        // Default rendering for plain text lines
                        return <p key={index} style={{ marginBottom: '0.5rem' }}>{line}</p>;
                    })}
                </div>
                
            </div>
        );
    }
    
    // Logic for Q&A content
    if (content.answer) {
        // Split answer by new lines to detect lists
        const answerLines = content.answer.trim().split('\n').map(line => line.trim()).filter(line => line.length > 0);
        
        // Check if content contains an ordered list (e.g., "1.")
        const isNumberedList = answerLines.some(line => /^\d+\.\s/.test(line));
        
        if (isNumberedList) {
            // Separate introductory text from list items
            const listStartIndex = answerLines.findIndex(line => /^\d+\.\s/.test(line));
            const introTextLines = listStartIndex === -1 ? [] : answerLines.slice(0, listStartIndex);
            const listItems = listStartIndex === -1 ? [] : answerLines.slice(listStartIndex);
            
            return (
                <div className="detail-content-area-list" style={{ textAlign: 'right', direction: 'rtl', padding: '0 0.5rem' }}> 
                    {/* Render intro text */}
                    {introTextLines.map((line, index) => (
                        <p key={`intro-${index}`} className="item-label" style={{ marginBottom: '1rem', color: '#4b5563', lineHeight: '1.6' }}>{line}</p>
                    ))}
                    
                    {/* Render ordered list (steps) */}
                    <ol className="faq-ordered-list" style={{ paddingRight: '20px', margin: '0 0 1rem 0' }}> 
                        {listItems.map((item, index) => (
                            <li key={`list-${index}`} style={{ marginBottom: '0.5rem', lineHeight: '1.6', color: '#4b5563' }}>
                                {/* Remove the number prefix */}
                                {item.replace(/^\d+\.\s*/, '')}
                            </li>
                        ))}
                    </ol>
                </div>
            );
        }

        // Default case for simple Q&A text
        return (
            <p className="item-label" style={{ lineHeight: '1.8', color: '#4b5563', whiteSpace: 'pre-wrap', padding: '0 0.5rem', textAlign: 'right', direction: 'rtl' }}>
                {content.answer}
            </p>
        );
    }
    
    // Default rendering for section-based content
    return (
        <div className="detail-content-area">
            {/* Wrapper for 'About Us' section with white card styling */}
            <div className="about-us-wrapper" style={{ 
                background: '#ffffff', // Set background to pure white
                borderRadius: '15px',
                padding: '25px',
                boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)',
                lineHeight: '1.7',
                color: '#333',
                fontSize: '0.95rem',
                textAlign: 'right', 
                direction: 'rtl',   
            }}>
                {/* Main description paragraph */}
                <p style={{ fontSize: '1rem', color: '#333', marginBottom: '1.5rem', lineHeight: '1.6', fontWeight: 'bold' }}>
                    {content.description}
                </p>
                
                {/* Iterate and render internal sections (list/text) */}
                {content.sections && content.sections.map((section, index) => (
                    <div key={index} style={{ marginTop: '1.5rem', padding: '0', background: 'none' }}>
                        {/* Section title */}
                        {section.title && <h3 style={{ color: '#1a202c', fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '0.8rem' }}>{section.title}</h3>}
                        
                        {/* List rendering (e.g., team members) */}
                        {section.type === 'list' && (
                            <ul style={{ listStyle: 'none', padding: 0 }}>
                                {section.items.map((item, i) => (
                                    <li key={i} style={{ marginBottom: '0.5rem', paddingRight: '1.5rem', position: 'relative', color: '#4b5563', fontSize: '1rem' }}>
                                        {/* Custom bullet point */}
                                        <span style={{ position: 'absolute', right: '0', color: '#1a202c' }}>•</span>
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        )}
                        
                        {/* Text content rendering */}
                        {section.type === 'text' && (
                            <p style={{ fontSize: '1rem', color: '#4b5563', marginTop: '1rem' }}>
                                {section.content}
                            </p>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};


// Main FaqDetail Component
const FaqDetail = () => {
  // Initialize navigation hook
  const navigate = useNavigate();
  // Get URL parameter 'id' for content lookup
  const { id } = useParams();
  
  // Look up content based on ID, providing a fallback for not-found content
  const content = faqContent[id] || { title: "المحتوى غير موجود", description: "نعتذر، لم نتمكن من العثور على هذا المحتوى.", sections: [] };

  return (
    <div className="settings-container">
      <div className="settings-mobile-frame">
        
        {/* Header bar with back button */}
        <div className="header-bar">
          <span
            className="material-symbols-outlined back-button"
            onClick={() => navigate(-1)} // Navigate back on click
          >
            arrow_back
          </span>
          <h1 className="header-title">{content.title}</h1> {/* Display content title */}
          <div className="header-spacer"></div>
        </div>

        {/* Scrollable content area (Right-to-Left) */}
        <div className="settings-scroll-content" dir="rtl" style={{ textAlign: 'right' }}>
          
          {/* Render the content based on its type */}
          <RenderFaqContent content={content} />

        </div>
      </div>
    </div>
  );
};

// Export the component for use in other files
export default FaqDetail
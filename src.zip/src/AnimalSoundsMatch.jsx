 import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react'; // importing React 
import './AnimalSoundsMatch.css'; // importing component styles

const defaultConfig = { // default configuration settings
  main_title: "لعبة تمييز أصوات الحيوانات", // game main title
  subtitle: ": استمع لصوت الحيوان ثم اختر الصورة المناسبة", // game subtitle
  feedback_correct: "", // message for correct answer
  feedback_wrong: "", // message for wrong answer
  background_color: "#ffffff", // background color of app
  surface_color: "#FCFBF3", // card/background surface color
  text_color: "#000000", // text color
  primary_action_color: "#22c55e", // correct progress bar color
  secondary_action_color: "#ef4444", // wrong color 
  font_family: "", // font family
  font_size: 16 // base font size
};

const QUESTION_SOUND = 'AnimalSoundsMatch'; // sound file played at start

const choices = [ // answer choices with emoji and labels
  { value: 'Elephant', label: 'الفيل', emoji: '🐘' }, 
  { value: 'Lion', label: 'الأسد', emoji: '🦁' }, 
  { value: 'Cat', label: 'القطة', emoji: '🐱' }, 
  { value: 'Dog', label: 'الكلب', emoji: '🐶' }, 
  { value: 'Horse', label: 'الحصان', emoji: '🐴' }, 
  { value: 'Chicken', label: 'الدجاجة', emoji: '🐔' } 
];

const stagesData = [ // game stages data and sounds
  { id: 1, soundToPlay: 'Dog', correctAnswer: "Dog" }, 
  { id: 2, soundToPlay: 'Cat', correctAnswer: "Cat" }, 
  { id: 3, soundToPlay: 'Horse', correctAnswer: "Horse" }, 
  { id: 4, soundToPlay: 'Elephant', correctAnswer: "Elephant" }, 
  { id: 5, soundToPlay: 'Lion', correctAnswer: "Lion" },
  { id: 6, soundToPlay: 'Chicken', correctAnswer: "Chicken" } 
];

const GAME_DURATION = 45; // total game time in seconds

const getStyle = (config, element) => { // function to return styles based on config and element type
  const font = config.font_family || defaultConfig.font_family; // choose font 
  const size = Number(config.font_size || defaultConfig.font_size); // choose font size 

  switch (element) { // check which style to apply based on element
    case 'body': // page body style
      return {
        backgroundColor: config.background_color, // set background color
        color: config.text_color, // set text color
        fontFamily: font, // apply chosen font
        fontSize: size + "px" // apply font size
      };
    case 'title': // title style
      return {
        fontSize: (size * 1.75) + "px", // larger font size for title
        color: config.text_color, // title color
        fontFamily: font // title font
      };
    case 'subtitle': // subtitle style
      return {
        fontSize: size + "px", // regular subtitle font
        color: config.text_color, // subtitle text color
        fontFamily: font // subtitle font
      };
    case 'card': // card (animal button) style
      return {
        backgroundColor: config.surface_color, // card background color
        color: config.text_color, // text color inside card
        fontFamily: font, // font for card labels
        fontSize: (size * 0.95) + "px" // slightly smaller font inside cards
      };
    default:
      return {}; // return empty style for unknown element
  }
};

export default function AnimalSoundsMatch({ onComplete }) { // main game component with callback onComplete
  const config = defaultConfig; // using default config for styling

  const [currentStageIndex, setCurrentStageIndex] = useState(0); // tracks current question index
  const [correctAttempts, setCorrectAttempts] = useState(0); // number of correct answers
  const [wrongAttempts, setWrongAttempts] = useState(0); // number of wrong answers

  const [micClicks, setMicClicks] = useState(0); // number of mic button presses
  const [skipped, setSkipped] = useState(0); // number of skipped questions due to timeout

  const [gameState, setGameState] = useState('loading'); // game state: loading → countdown → active → completed
  const [countdown, setCountdown] = useState(3); // countdown value (3..2..1)

  const [timeLeft, setTimeLeft] = useState(GAME_DURATION); // remaining time in the game
  const [timerActive, setTimerActive] = useState(false); // timer control (starts after countdown)

  const startTimeRef = useRef(Date.now()); // stores the start time of gameplay
  const audioRef = useRef(null); // reference for main playing sound
  const audioCardRef = useRef(null); // reference for choice button sound
  const totalStages = stagesData.length; // total number of game stages

  const stopSound = useCallback(() => { // stops any currently playing audio
    if (audioRef.current) { // if main audio exists
      audioRef.current.pause(); // pause it
      audioRef.current.currentTime = 0; // reset playback to start
      audioRef.current = null; // clear reference
    }

    if (audioCardRef.current) { // if card audio exists
      audioCardRef.current.pause(); // pause it
      audioCardRef.current.currentTime = 0; // reset playback
      audioCardRef.current = null; // clear reference
    }
  }, []); 

  const getAudioPath = (soundName) => `/sounds/${soundName}.mp3`; // returns path to audio file

  const handleTimeout = useCallback(() => { // called when game time runs out
    setTimerActive(false); // stop the timer
    setGameState('completed'); // mark game as completed
    stopSound(); // stop any playing audio

    const remainingStages = totalStages - currentStageIndex; // calculate skipped questions
    setSkipped(remainingStages); // update skipped counter

    const durationSeconds = GAME_DURATION; // total game duration

    if (onComplete) onComplete({ // send game results to parent
      type: 'audio', // game type
      correct: correctAttempts, // correct answers
      wrong: wrongAttempts, // wrong answers
      duration_seconds: durationSeconds, // duration in seconds
      skipped: remainingStages, // skipped questions
      mic_clicks: micClicks, // mic button presses
      drag_cancels: 0, // unused counter for now
    });
  }, [correctAttempts, wrongAttempts, onComplete, stopSound, totalStages, currentStageIndex, micClicks]); // dependencies

  // 1. Play starting sound on loading
  useEffect(() => {
    if (gameState === 'loading') { // only on loading state
        const qSound = new Audio(getAudioPath(QUESTION_SOUND)); // create audio
        audioRef.current = qSound; // store reference
        qSound.play(); // play start sound

        qSound.onended = () => { // after sound ends
            setGameState('countdown'); // start countdown
            audioRef.current = null; // clear reference
        };
    }
  }, [gameState]); // run effect when gameState changes

  // 2. Countdown effect
  useEffect(() => {
    if (gameState === 'countdown' && countdown > 0) { // if counting down
        const timer = setTimeout(() => { // schedule next tick
            setCountdown(prev => prev - 1); // decrease countdown
        }, 1000);
        return () => clearTimeout(timer); // cleanup timeout
    } 
    else if (gameState === 'countdown' && countdown === 0) { // countdown finished
        startTimeRef.current = Date.now(); // mark actual game start
        setGameState('active'); // set game active
        setTimerActive(true); // start timer
    }
  }, [gameState, countdown]); // dependencies

  
  // 3. Game timer effect
  useEffect(() => {
    if (!timerActive || timeLeft <= 0) { // stop if timer inactive or time ended
      if (timeLeft === 0) { // if time ended
        handleTimeout(); // trigger timeout
      }
      return; // exit effect
    }

    const interval = setInterval(() => { // decrease time every second
      setTimeLeft((prevTime) => prevTime - 1); // update remaining time
    }, 1000);

    return () => clearInterval(interval); // cleanup interval
  }, [timerActive, timeLeft, handleTimeout]); // dependencies

  // 4. Play first stage sound when game becomes active
  useEffect(() => {
    if (gameState === 'active' && currentStageIndex === 0) { // first stage only
        const stage = stagesData[currentStageIndex]; // get current stage
        const cSound = new Audio(getAudioPath(stage.soundToPlay)); // create audio
        audioRef.current = cSound; // store reference
        cSound.play(); // play sound
    }
  }, [gameState]); // run once when gameState changes to active

  const playSound = useCallback(() => { // play sound for current stage button
    if (gameState !== 'active') return; // prevent if game inactive

    setMicClicks(prev => prev + 1); // increment mic button counter

    stopSound(); // stop any existing sound

    const currentStage = stagesData[currentStageIndex]; // get current stage
    if (!currentStage) return; //  check

    const cardSound = currentStage.soundToPlay; // sound to play

    const sound = new Audio(getAudioPath(cardSound)); // create audio
    audioRef.current = sound; // store reference
    sound.play(); // play sound
  }, [currentStageIndex, stopSound, gameState]); // dependencies

  // 5. Check answer function
  const checkAnswer = useCallback(
    (choice) => {
      if (gameState !== 'active') return; // prevent if game inactive
      stopSound(); // stop any playing sound

      const correct = stagesData[currentStageIndex].correctAnswer; // correct answer
      const isCorrect = choice === correct; // check if choice is correct

      const newCorrect = correctAttempts + (isCorrect ? 1 : 0); // update correct attempts
      const newWrong = wrongAttempts + (isCorrect ? 0 : 1); // update wrong attempts

      setCorrectAttempts(newCorrect); // set new correct count
      setWrongAttempts(newWrong); // set new wrong count

      const next = currentStageIndex + 1; // index of next stage

      if (next >= totalStages) { // if last stage completed
        setTimerActive(false); // stop timer
        setGameState('completed'); // mark game completed
        const durationSeconds = Math.round((Date.now() - startTimeRef.current) / 1000); // calculate duration
        
        setTimeout(() => { // slight delay before sending results
          if (onComplete) onComplete({ // send results
            type: 'audio',
            correct: newCorrect,
            wrong: newWrong,
            duration_seconds: durationSeconds,
            skipped: 0, // skipped questions
            mic_clicks: micClicks, // mic button count
            drag_cancels: 0, // temporary placeholder
          });
        }, 500);
        return;
      }

      setTimeout(() => { // move to next stage after delay
        setCurrentStageIndex(next); // update current stage
      }, 500);
    },
    [currentStageIndex, correctAttempts, wrongAttempts, totalStages, stopSound, onComplete, gameState, micClicks] // dependencies
  );

  // 6. Play stage sound on stage change (>0)
  useEffect(() => {
    if (gameState === 'active' && currentStageIndex > 0) { // only after first stage
      const stage = stagesData[currentStageIndex]; // get stage
      const cSound = new Audio(getAudioPath(stage.soundToPlay)); // create audio
      audioRef.current = cSound; // store reference
      cSound.play(); // play sound
    }
  }, [currentStageIndex, gameState]); // dependencies
  
    const ProgressStep = ({ index }) => { // single step in progress bar
    let color = 'rgb(209 213 219)'; // default gray color
    if (index < currentStageIndex) color = config.primary_action_color; // completed step color
    else if (index === currentStageIndex) color = 'blue'; // current step color

    return (
      <div
        className="flex-1 h-3 rounded-full" // step bar style
        style={{ backgroundColor: color }} // set step color
      ></div>
    );
  };

  const MemoizedProgress = useMemo(
    () => (
      <div className="flex flex-row-reverse items-center gap-2">
        {stagesData.map((_, i) => (
          <ProgressStep key={i} index={i} /> // render each progress step
        ))}
      </div>
    ),
    [currentStageIndex] // update memo when current stage changes
  );
  
  return (
    <div className="game-container" style={getStyle(config, 'body')}> 
      <div className="w-full max-w-4xl rounded-3xl shadow-2xl p-6 flex flex-col gap-6" 
        style={{ backgroundColor: config.surface_color, position: 'relative' }} // card container
      >
        
        {(gameState === 'loading' || gameState === 'countdown') && ( // show countdown overlay
            <div className="countdown-display">
                <span className="countdown-number">
                    {gameState === 'loading' ? '' : countdown}
                </span>
            </div>
        )}
        
        <div className="flex items-center justify-between w-full mt-2"> 
          <button
            onClick={playSound} // play current animal sound
            aria-label="تشغيل صوت الحيوان"
            disabled={gameState !== 'active'} // disable if game inactive
            className="audio-button-visual w-12 h-12 flex items-center justify-center text-white rounded-full text-2xl shadow-lg transition"
            style={{ backgroundColor: '#3b82f6' }} // mic button style
          >
            🎙️
          </button>

          <h1 className="text-3xl font-bold text-black text-center flex-1" style={getStyle(config, 'title')}>
            {config.main_title} 
          </h1>

          <div 
            className={`timer-box ${timeLeft <= 5 ? "timer-warning" : ""}`} // timer box, warning if <=5
          >
            <span>⏳</span> 
            <span>{timeLeft}</span> 
          </div>
        </div>

        <p className="text-center text-black text-lg" style={getStyle(config, 'subtitle')}>
          {config.subtitle} 
        </p>

        <main className="game-main"> 
          <section className="progress-section"> 
            <span style={{ color: config.text_color }}>
              المرحلة {currentStageIndex + 1} من {totalStages} 
            </span>
            {MemoizedProgress} 
          </section>

          <section className="cards-section">
            <div className="cards-grid">
              {choices.map((choice) => ( // render all choice cards
                <button
                  key={choice.value}
                  className="card-button"
                  onClick={() => checkAnswer(choice.value)} // handle choice click
                  disabled={gameState !== 'active'} // disable if game inactive
                  style={getStyle(config, 'card')} // apply card style
                >
                  <span className="card-emoji-wrapper">
                    <span>{choice.emoji}</span> 
                  </span>
                  <span className="card-label">{choice.label}</span>
                </button>
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
import React from 'react'; // Import React library
import { useNavigate } from 'react-router-dom'; // Import navigation 
import './Settings.css'; // Import CSS styles


const HelpSupportItem = ({ label, iconName, onClick, isLink = true }) => { // Component for each help item
  return (
    <div className="settings-item" onClick={onClick}> {/* Clickable container */}
      <div className="item-content"> {/* Content wrapper */}
        <span className="material-symbols-outlined main-icon"> 
          {iconName} {/* Display icon name */}
        </span>
        <p className="item-label"> 
          {label} 
        </p>
        {isLink && ( // Conditionally render arrow if it's a link
          <span className="material-symbols-outlined arrow-icon"> 
            chevron_left  {/* Left chevron for RTL */}
          </span>
        )}
      </div>
    </div>
  );
};


const HelpSupport = () => { // Main help and support component
  const navigate = useNavigate(); // Initialize navigation function

  const handleDirectAction = (action) => { // Handler for direct actions
    console.log(`Executing direct action: ${action}`); // Log action to console
  };


  return (
    <div className="settings-container"> {/* Main container */}
      <div className="settings-mobile-frame"> {/* Mobile frame wrapper */}
        
        <div className="header-bar"> {/* Header bar */}
          <span  // Back button
              className="material-symbols-outlined back-button" // Back button styling
              onClick={() => navigate(-1)} // Navigate to previous page
            >
            arrow_back 
          </span> 

          <h1 className="header-title">المساعدة والدعم</h1> 
          <div className="header-spacer"></div> {/* Spacer for alignment */}
        </div>

        <div className="settings-scroll-content"> {/* Scrollable content area */}

          <h2 className="section-title">الأسئلة الشائعة</h2> 
          <div className="settings-section"> {/* FAQ section container */}
            <HelpSupportItem // FAQ item 1
              label="كيف أضيف طفلاً جديداً؟" 
              iconName="live_help"  
              onClick={() => navigate('/faq/add-child')}  // Navigate to add child FAQ
            />
            <HelpSupportItem // FAQ item 2
              label="كيف أتابع تقدم طفلي؟" 
              iconName="live_help"
              onClick={() => navigate('/faq/track-progress')}  // Navigate to track progress FAQ
            />
            <HelpSupportItem // FAQ item 3
              label="ما هي أنواع الاختبارات المتوفرة؟" 
              iconName="live_help" 
              onClick={() => navigate('/faq/test-types')}  // Navigate to test types FAQ
            />
          </div>

          <h2 className="section-title">تواصل مع الدعم الفني</h2> 
          <div className="settings-section"> {/* Support section container */}
            <HelpSupportItem // Support item 1
              label="من نحن" 
              iconName="group" 
              onClick={() => navigate('/faq/about-us')} // Navigate to about us page
            />
            {/* Edit here: Restored "mail" icon */}
            <HelpSupportItem // Support item 2
              label="تواصل معنا" 
              iconName="mail"  
              onClick={() => navigate('/faq/contact-us')} // Navigate to contact us page
            />
          </div>

          <h2 className="section-title">مصادر إضافية</h2> 
          <div className="settings-section"> {/* Resources section container */}
            <HelpSupportItem // Resource item 1
              label="دليل استخدام التطبيق" 
              iconName="book" 
              onClick={() => navigate('/faq/user-guide')} // Navigate to user guide
            />
            <HelpSupportItem // Resource item 2
              label="شروط الخدمة وسياسة الخصوصية" 
              iconName="description" 
              onClick={() => navigate('/faq/terms-privacy')} // Navigate to terms and privacy
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpSupport; // Export component
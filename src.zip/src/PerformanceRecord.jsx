import React, { useEffect, useState } from "react"; // Import React 
import { useLocation, useNavigate } from "react-router-dom"; // Import routing 
import "./PerformanceRecord.css"; // Import CSS styles

export default function PerformanceRecord() {
  const location = useLocation(); // Get location object for state access
  const navigate = useNavigate(); // Initialize navigation function

  const child = location.state?.child; // Get child data from navigation state

  const [records, setRecords] = useState([]); // State for performance records
  const [loading, setLoading] = useState(true); // State for loading status

  useEffect(() => { // Effect runs when child data changes
    if (!child?.id) return; // Exit if no child ID

    fetch(`http://localhost:3001/performance-records/${child.id}`) // Fetch performance records for child
      .then((res) => res.json()) // Parse response as JSON
      .then((data) => { // Handle successful response
        setRecords(data.records || []); // Update records state with fetched data
        setLoading(false); // Set loading to false
      })
      .catch((err) => { // Handle fetch error
        console.error(err); // Log error to console
        setLoading(false); // Set loading to false
      });
  }, [child]); // Re-run effect when child changes

  if (!child) return <p className="performance-loading">❌ لم يتم العثور على بيانات الطفل</p>; // Display error if no child data
  if (loading) return <p className="performance-loading">جاري التحميل...</p>; // Display loading message

  return (
    <div className="performance-page-container"> {/* Main page container */}

      {/* MAIN CONTAINER */}
      <div className="performance-main-container"> {/* Main content wrapper */}

        {/* HEADER CARD */}
        <div className="performance-header-card"> {/* Header section */}

          {/* Back Button */}
          <span
            className="material-symbols-outlined performance-back-btn" 
            onClick={() => navigate(-1)} // Navigate back on click
          >
            arrow_back 
          </span>

          {/* Title */}
          <h1 className="performance-page-title">سجل الأداء</h1> 

          {/* Child Info */}
          <div className="performance-child-card"> {/* Child information card */}
            <div className="performance-child-img-wrapper"> {/* Image wrapper */}
              <img
                src={child.image || "https://i.ibb.co/3F0xXJ3/kid-avatar-1.png"} // Child image or default avatar
                alt={child.child_name} // Alt text for image
              />
            </div>

            <div> {/* Child name container */}
              <p className="performance-child-label">سجل أداء:</p> 
              <p className="performance-child-name">{child.child_name}</p> {/* Child name */}
            </div>
          </div>
        </div>

        {/* RECORDS CONTAINER */}
        <div className="performance-records-container"> {/* Records list container */}
          {records.length === 0 ? ( // Check if no records exist
            <p className="performance-no-records">لا توجد نتائج لهذا الطفل</p> // Display no records message
          ) : (
            records.map((item) => ( // Map through records array
              <div className="performance-record-card" key={item.id}> {/* Individual record card */}

                <p className="performance-date"> {/* Display record date */}
                  {item.created_at.split("T")[0]} {/* Extract date from timestamp */}
                </p>

                <p className="performance-dominant"> {/* Display dominant learning style */}
                  النمط:{" "} 
                  <span> {/* Style value wrapper */}
                    {item.dominant === "visual" // Check dominant style
                      ? "بصري" 
                      : item.dominant === "audio" // Check if audio
                      ? "سمعي" 
                      : "مختلط"} 
                  </span>
                </p>

                {/* Stats Section */}
                <div className="performance-stats-box"> {/* Statistics container */}
                 <div 
                    className="performance-stat-card" // Audio stat card
                    data-percentage={`${item.audio ?? 0}%`} // Set data attribute for styling
                  >
                    <p className="performance-label">سمعي</p> 
                    <p className="performance-value">{item.audio ?? 0}%</p> {/* Audio percentage */}
                  </div>

                  <div className="performance-divider"></div> {/* Divider between stats */}

                  <div 
                    className="performance-stat-card" // Visual stat card
                    data-percentage={`${item.visual ?? 0}%`} // Set data attribute for styling
                  >
                    <p className="performance-label">بصري</p> 
                    <p className="performance-value">{item.visual ?? 0}%</p> {/* Visual percentage */}
                  </div>

                  <div className="performance-divider"></div> {/* Divider between stats */}

                  <div className="performance-stat-card"> {/* Duration stat card */}
                    <p className="performance-label">المدة</p> 
                    <p className="performance-value">{item.duration_seconds} ثانية</p> {/* Duration in seconds */}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
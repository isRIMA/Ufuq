import React from "react"; // Import React library
import { useNavigate } from "react-router-dom"; // Import navigation 

export default function Home() { // Home page component
  const navigate = useNavigate(); // Initialize navigation function

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-white overflow-x-hidden font-display"> {/* Main container with full screen height */}

      <style>{` /* Inline styles */}
        .wide-words { word-spacing: 4px; } /* Add spacing between words */}

        /* Box with same styling as login and signup pages */
        .home-box { /* Home box container styles */}
          background: #FCFBF3; /* Light cream background */}
          border: 1px solid rgba(0,0,0,0.12); /* Subtle border */}
          border-radius: 20px; /* Rounded corners */}
          padding: 45px 30px; /* Internal padding */}
          box-shadow: 0 8px 25px rgba(0,0,0,0.12); /* Shadow effect */}
          max-width: 650px; /* Maximum width */}
          margin: auto; /* Center horizontally */}
        }

        /* Fonts same as login pages */
        .home-title { /* Title text styles */}
          font-weight: 800; /* Extra bold */}
          font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif; /* Font family */}
          color: #1c3144; /* Dark blue color */}
        }

        .home-sub { /* Subtitle text styles */}
          font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif; /* Font family */}
          color: #495057; /* Gray color */}
        }

        .home-desc { /* Description text styles */}
          font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif; /* Font family */}
          color: #495057; /* Gray color */}
        }
      `}</style>

      <main className="flex flex-1 w-full flex-col items-center justify-center p-6 text-center"> {/* Main content area centered */}

        <div className="w-full home-box"> {/* Home box container */}
 
          {/* Top Icon */}
          <div className="mb-12"> {/* Icon section with bottom margin */}
            <div className="inline-flex items-center justify-center rounded-xl bg-[#FFA07A] p-4 text-white shadow-lg"> {/* Icon background circle */}
              <span // Visibility icon
                className="material-symbols-outlined" // Material icon class
                style={{ fontVariationSettings: "'FILL' 1" }} // Fill icon style
              >
                visibility 
              </span>
            </div>

            <h1 className="home-title mt-4 text-6xl tracking-tight text-neutral-text"> {/* App name title */}
              أفــق 
            </h1>
          </div>

          {/* Subtitle */}
          <h2 className="home-sub text-neutral-text tracking-light text-[32px] font-bold leading-tight"> 
            أهلاً بك في عالم طفلك 
          </h2>

          <p className="home-desc wide-words mt-3 max-w-xs mx-auto text-center text-neutral-text/70 text-lg"> 
            نساعدك على اكتشاف نمط انتباه طفلك 
          </p>

          {/* Decorative Icons  */}
          <div className="my-10 px-4"> {/* Decorative icons container */}
            <div className="relative aspect-square max-w-[280px] mx-auto"> {/* Square container for icons */}

              <div className="absolute -top-4 -left-4 w-20 h-20 bg-[#87CEEB]/50 rounded-full flex items-center justify-center"> {/* Top-left icon circle */}
                <span className="material-symbols-outlined text-[#1E90FF] !text-4xl"> {/* Hearing icon */}
                  hearing 
                </span>
              </div>

              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-[#FFD700]/50 rounded-2xl flex items-center justify-center"> {/* Bottom-right icon square */}
                <span className="material-symbols-outlined text-[#FFA500] !text-5xl"> {/* Toys icon */}
                  toys 
                </span>
              </div>

              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#98FB98]/50 rounded-full flex items-center justify-center shadow-inner"> {/* Center large icon circle */}
                <span className="material-symbols-outlined text-[#32CD32] !text-7xl"> {/* Psychology icon */}
                  psychology 
                </span>
              </div>

              <div className="absolute -bottom-2 -left-8 w-16 h-16 bg-[#FFB6C1]/50 rounded-full flex items-center justify-center"> {/* Bottom-left icon circle */}
                <span className="material-symbols-outlined text-[#FF69B4] !text-3xl"> {/* Star icon */}
                  star 
                </span>
              </div>

              <div className="absolute top-0 -right-5 w-14 h-14 bg-[#DDA0DD]/50 rounded-2xl flex items-center justify-center rotate-12"> {/* Top-right rotated icon square */}
                <span className="material-symbols-outlined text-[#BA55D3] !text-3xl"> {/* Extension icon */}
                  extension 
                </span>
              </div>

            </div>
          </div>

          {/* Start Button */}
          <div className="mt-16 w-full px-4"> {/* Button container */}
            <button 
              onClick={() => navigate("/login")} // Navigate to login page on click
              className="flex h-16 w-full max-w-sm mx-auto items-center justify-center gap-3 rounded-xl bg-primary px-6 text-xl font-bold text-white shadow-lg shadow-primary/30 transition-all hover:bg-primary/90" // Button styling
            >
              هيا نبدأ 
              <span className="material-symbols-outlined !text-3xl">arrow_forward</span> {/* Forward arrow icon */}
            </button>
          </div>

        </div>
      </main>

      {/* Background Decorative Elements  */}
      <div // Bottom-left decorative blur
        aria-hidden="true" // Hidden from screen readers
        className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-[#87CEEB]/20 dark:bg-[#87CEEB]/10 blur-xl" // Blue blurred circle
      ></div>

      <div // Top-right decorative blur
        aria-hidden="true" // Hidden from screen readers
        className="absolute -top-10 -right-20 h-56 w-56 rounded-full bg-[#FFD700]/20 dark:bg-[#FFD700]/10 blur-xl" // Gold blurred circle
      ></div>

    </div>
  );
}
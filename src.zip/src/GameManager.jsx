import React, { useState, useEffect, useCallback } from "react"; // Import React 
import { useLocation } from "react-router-dom"; // Import router for location state
import AnimalSoundsMatch from "./AnimalSoundsMatch"; // Import game component 1
import ColorMatching from "./ColorMatching"; // Import game component 2
import SoundMatch from "./SoundMatch"; // Import game component 3
import FoodSorting from "./FoodSorting"; // Import game component 4
import Report from "./Report"; // Import report component

export default function GameManager() {
  const location = useLocation(); // Get current location from router
  const child = location.state?.child; // Extract child data from location state
  const childId = child?.id || null; // Get child ID or set to null

  const [currentGame, setCurrentGame] = useState(0); // Track current game index
  const [testResultId, setTestResultId] = useState(null); // Store main test result ID

  const [gameSummaries, setGameSummaries] = useState([]); // Store all game summaries

  const [finalScores, setFinalScores] = useState({ // Initialize final scores object
    visual_correct: 0, // Visual correct answers count
    visual_wrong: 0, // Visual wrong answers count
    audio_correct: 0, // Audio correct answers count
    audio_wrong: 0, // Audio wrong answers count
    duration_seconds: 0, // Total duration in seconds
    skipped: 0, // Total skipped questions
    mic_clicks: 0, // Total mic button clicks
    drag_cancels: 0, // Total drag cancellations
  });

  // Save individual game details to database

  const saveGameDetail = useCallback(async (detail, mainTestId) => {
    try {
      if (!mainTestId) { // Check if main test ID exists
        console.error("mainTestId is null. Cannot save game detail."); // Log error if missing
        return; // Exit function
      }

      const response = await fetch("http://localhost:3001/save-game-detail", { // Send POST request
        method: "POST", // HTTP method
        headers: { "Content-Type": "application/json" }, // Set content type
        body: JSON.stringify({ // Convert data to JSON
          test_result_id: mainTestId, // Link to main test
          game_name: detail.gameName, // Game name
          correct_answers: detail.correct, // Correct answers count
          wrong_answers: detail.wrong, // Wrong answers count
          skipped_answers: detail.skipped, // Skipped answers count
          duration_seconds: detail.durationSeconds, // Game duration
          mic_clicks: detail.mic_clicks || 0, // Mic clicks count
          drag_cancels: detail.drag_cancels || 0, // Drag cancels count
        }),
      });

      if (!response.ok) { // Check if response failed
        const errorText = await response.text(); // Get error text
        console.error(`Error saving ${detail.gameName} detail. Status: ${response.status}`, errorText); // Log error
      } else {
        console.log(`${detail.gameName} detail saved successfully.`); // Log success
      }
    } catch (error) {
      console.error("Error connecting to server for game detail:", error); // Log connection error
    }
  }, []); 

  const saveTestResults = useCallback(
    async (finalScores, summaries) => {

      // Calculate performance percentages
      // Calculate visual performance: correct / (correct + wrong + skipped + drag_cancels)
      const totalVisualInteractions = // Sum all visual interactions
        finalScores.visual_correct + // Visual correct
        finalScores.visual_wrong + // Visual wrong
        finalScores.skipped + // Skipped items
        finalScores.drag_cancels; // Drag cancellations

      const visualScore = // Calculate visual score percentage
        totalVisualInteractions > 0 // Check if there are interactions
          ? Math.round( // Round to nearest integer
              (finalScores.visual_correct / totalVisualInteractions) * 100 // Calculate percentage
            )
          : 0; // Default to 0 if no interactions

      // Calculate audio performance: correct / (correct + wrong + skipped + mic_clicks)
      const totalAudioInteractions = // Sum all audio interactions
        finalScores.audio_correct + // Audio correct
        finalScores.audio_wrong + // Audio wrong
        finalScores.skipped + // Skipped items
        finalScores.mic_clicks; // Mic clicks

      const audioScore = // Calculate audio score percentage
        totalAudioInteractions > 0 // Check if there are interactions
          ? Math.round( // Round to nearest integer
              (finalScores.audio_correct / totalAudioInteractions) * 100 // Calculate percentage
            )
          : 0; // Default to 0 if no interactions

      // Determine attention type
      const diff = Math.abs(visualScore - audioScore); // Calculate absolute difference
      let dominant = "mixed"; // Default to mixed attention

      if (diff >= 7) { // If difference is significant (7% or more)
        dominant = visualScore > audioScore ? "visual" : "audio"; // Determine dominant type
      }

      const totalCorrect = // Sum total correct answers
        finalScores.visual_correct + finalScores.audio_correct; // Visual + audio correct
      const totalWrong = // Sum total wrong answers
        finalScores.visual_wrong + finalScores.audio_wrong; // Visual + audio wrong

      if (!childId) { // Check if child ID exists
        console.warn("No childId provided — cannot save result."); // Log warning
        return; // Exit function
      }

      try {
        const totalResponse = await fetch( // Send POST request to save main test
          "http://localhost:3001/save-test-result", // API endpoint
          {
            method: "POST", // HTTP method
            headers: { "Content-Type": "application/json" }, // Set content type
            body: JSON.stringify({ // Convert data to JSON
              child_id: childId, // Child identifier
              visual: visualScore, // Visual score percentage
              audio: audioScore, // Audio score percentage
              dominant: dominant, // Dominant attention type
              total_correct: totalCorrect, // Total correct answers
              total_wrong: totalWrong, // Total wrong answers
              total_skipped: finalScores.skipped, // Total skipped
              duration_seconds: finalScores.duration_seconds, // Total duration
              mic_clicks: finalScores.mic_clicks, // Total mic clicks
              drag_cancels: finalScores.drag_cancels, // Total drag cancels
            }),
          }
        );

        if (!totalResponse.ok) { // Check if response failed
          const errorText = await totalResponse.text(); // Get error text
          throw new Error( // Throw error
            `Failed to save total test result. Status: ${totalResponse.status}. Error: ${errorText}` // Error message
          );
        }

        const resultData = await totalResponse.json(); // Parse response JSON
        const mainTestId = resultData.id; // Extract test result ID

        setTestResultId(mainTestId); // Store test result ID in state

        for (const summary of summaries) { // Loop through all game summaries
          await saveGameDetail(summary, mainTestId); // Save each game detail
        }

        console.log("All results and game details saved successfully!"); // Log success
      } catch (error) {
        console.error("Error during full test result save process:", error); // Log error
      }
    },
    [childId, saveGameDetail, setTestResultId] // Dependencies array
  );

  // Handle completion of each game
  const handleGameComplete = (gameName, gameResult = {}) => {
    const type = gameResult.type || "mixed"; // Get game type or default to mixed

    const skipped = gameResult.skipped || 0; // Get skipped count or default to 0
    const micClicks = gameResult.mic_clicks || 0; // Get mic clicks or default to 0
    const dragCancels = gameResult.drag_cancels || 0; // Get drag cancels or default to 0

    setGameSummaries((prev) => [ // Update game summaries array
      ...prev, // Spread previous summaries
      {
        id: prev.length + 1, // Generate sequential ID
        gameName: gameName, // Store game name
        type: type, // Store game type
        correct: gameResult.correct || 0, // Store correct count
        wrong: gameResult.wrong || 0, // Store wrong count
        durationSeconds: gameResult.duration_seconds || 0, // Store duration
        skipped: skipped, // Store skipped count
        mic_clicks: micClicks, // Store mic clicks
        drag_cancels: dragCancels, // Store drag cancels
      },
    ]);

    setFinalScores((prev) => ({ // Update final scores
      ...prev, // Spread previous scores
      visual_correct: // Update visual correct
        prev.visual_correct + // Previous count
        (type === "visual" ? gameResult.correct || 0 : 0), // Add if visual type
      visual_wrong: // Update visual wrong
        prev.visual_wrong + // Previous count
        (type === "visual" ? gameResult.wrong || 0 : 0), // Add if visual type
      audio_correct: // Update audio correct
        prev.audio_correct + // Previous count
        (type === "audio" ? gameResult.correct || 0 : 0), // Add if audio type
      audio_wrong: // Update audio wrong
        prev.audio_wrong + // Previous count
        (type === "audio" ? gameResult.wrong || 0 : 0), // Add if audio type
      duration_seconds: // Update total duration
        prev.duration_seconds + (gameResult.duration_seconds || 0), // Add game duration
      skipped: prev.skipped + skipped, // Add skipped count
      mic_clicks: prev.mic_clicks + micClicks, // Add mic clicks
      drag_cancels: prev.drag_cancels + dragCancels, // Add drag cancels
    }));

    setCurrentGame((p) => p + 1); // Move to next game
  };

  const games = [ // Array of game components
    <AnimalSoundsMatch // Game 1
      key="game1" // Unique key
      onComplete={(result) => // Completion callback
        handleGameComplete("AnimalSoundsMatch", result) // Handle game completion
      }
    />,
    <ColorMatching // Game 2
      key="game2" // Unique key
      onComplete={(result) => // Completion callback
        handleGameComplete("ColorMatching", result) // Handle game completion
      }
    />,
    <SoundMatch // Game 3
      key="game3" // Unique key
      onComplete={(result) => // Completion callback
        handleGameComplete("SoundMatch", result) // Handle game completion
      }
    />,
    <FoodSorting // Game 4
      key="game4" // Unique key
      onComplete={(result) => // Completion callback
        handleGameComplete("FoodSorting", result) // Handle game completion
      }
    />,
  ];

  useEffect(() => { // Effect to save results when all games complete
    if (currentGame < games.length) return; // Exit if games not finished

    saveTestResults(finalScores, gameSummaries); // Save all test results
  }, [currentGame, finalScores, gameSummaries, saveTestResults]); // Dependencies

  if (currentGame >= games.length) { // Check if all games completed
    return (
      <Report // Render report component
        childId={childId} // Pass child ID
        gameSummaries={gameSummaries} // Pass game summaries
        finalScores={finalScores} // Pass final scores
      />
    );
  }

  return <div>{games[currentGame]}</div>; // Render current game
}
import React, { useState } from "react"; // Import React 
import { useLocation, useNavigate } from "react-router-dom"; // Routing 
import { isFieldRequired } from "./ValidationFunctions"; // Validation function
import "./ChildProfile.css"; // Component styles

export default function ChildProfile() { // Component start
  const location = useLocation(); // Get route data
  const navigate = useNavigate(); // Navigation handler

  const userData =
    location.state?.userData || JSON.parse(localStorage.getItem("userData")); // Load user data

  const [childName, setChildName] = useState(""); // Child name state
  const [childAge, setChildAge] = useState(4); // Child age state
  const defaultAvatar = "https://cdn-icons-png.flaticon.com/512/456/456212.png"; // Default avatar 
  const [childImg, setChildImg] = useState(defaultAvatar); // Child image state
  const [errors, setErrors] = useState({}); // Error messages state

  const handleImageChange = (e) => { // Handle avatar change
    const file = e.target.files[0]; // Get selected file
    if (file) {
      const reader = new FileReader(); // Create FileReader
      reader.onload = () => setChildImg(reader.result); // Update preview
      reader.readAsDataURL(file); // Convert to Base64
    }
  };

  const validateAddChild = () => { // Validate form input
    const validationErrors = {}; // Prepare errors object

    const nameError = isFieldRequired(childName, 'اسم الطفل'); // Validate name
    if (nameError) validationErrors.childName = nameError; // Add error

    setErrors(validationErrors); // Save errors
    return Object.keys(validationErrors).length === 0; // Valid
  };

  const handleSave = async () => { // Save new child
    if (!validateAddChild()) return; // Stop on validation fail

    const parentId = userData?.id; // Get parent ID
    if (!parentId) { // If no user
      alert("خطأ: لا توجد بيانات مستخدم! أعيدي تسجيل الدخول."); // Show error
      navigate("/login"); // Redirect to login
      return;
    }

    try {
      const response = await fetch("http://localhost:3001/add-child", { // API request
        method: "POST", // POST method
        headers: { "Content-Type": "application/json" }, // JSON header
        body: JSON.stringify({ // Request body
          parentId: userData.id, // Parent ID
          child_name: childName, // Child name
          age: childAge, // Child age
          image: childImg, // Child image
        }),
      });

      const data = await response.json(); // Parse JSON response

      if (response.ok) { // Success case
        alert("تم إضافة الطفل بنجاح!"); // Show success message

        const updatedUser = { // Update user data
          ...userData,
          children: [
            ...(userData.children || []), // Existing children
            {
              id: data.childId, // New child ID
              child_name: childName, // Name
              age: childAge, // Age
              image: childImg, // Image
            },
          ],
        };

        localStorage.setItem("userData", JSON.stringify(updatedUser)); // Save updated user

        navigate("/dashboard", { state: { userData: updatedUser } }); // Go to dashboard

      } else {
        setErrors({ general: data.msg || "حدث خطأ عند إضافة الطفل" }); // Show server error
      }
    } catch (error) {
      setErrors({ general: "خطأ في الاتصال بالسيرفر، حاول مرة أخرى" }); // Network error
      console.error(error); // Log error
    }
  };

  const handleChildNameChange = (e) => { // Input change handler
    setChildName(e.target.value); // Update name
    if (errors.childName) setErrors(prev => ({ ...prev, childName: "" })); // Clear error
  };

  return ( // Render UI
    <div
      className="child-profile-page flex min-h-screen items-center justify-center p-4" // Page layout
      dir="rtl" // Right-to-left layout
    >
      <div className="child-profile-card w-full max-w-md rounded-xl shadow-lg p-6 flex flex-col gap-6"> {/* Card container */}
        
        <div className="flex items-center justify-between"> {/* Header */}
          <span
            className="material-symbols-outlined back-button" // Back arrow
            onClick={() => navigate(-1)} // Go back
          >
            arrow_back {/* Icon */}
          </span>

          <h2 className="text-center text-text-dark dark:text-text-light text-lg font-bold flex-1"> {/* Page title */}
            ملف الطفل 
          </h2>

          <div className="w-10"></div> {/* Spacer */}
        </div>

        <div className="flex flex-col items-center gap-4"> {/* Image section */}
          <div className="relative group"> {/* Avatar wrapper */}
            
            <div
              className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-32 w-32 border-4 border-white dark:border-background-dark shadow-lg cursor-pointer" // Avatar circle
              style={{ backgroundImage: `url(${childImg})` }} // Current image
              onClick={() => document.getElementById("childImageInput").click()} // Open file picker
            ></div>

            <input
              type="file" // File input
              id="childImageInput" // Hidden input ID
              accept="image/*" // Only images
              onChange={handleImageChange} // Update image
              style={{ display: "none" }} // Hide input
            />

            <div
              className="absolute bottom-0 left-0 flex items-center justify-center size-10 bg-primary rounded-full text-white cursor-pointer shadow-md group-hover:scale-110 transition-transform" // Edit button style
              onClick={() => document.getElementById("childImageInput").click()} // Trigger file input
            >
              <span className="material-symbols-outlined">edit</span> {/* Edit icon */}
            </div>
          </div>

          <p className="text-text-dark dark:text-text-light text-xl font-bold text-center"> {/* Image hint */}
            اختر صورة لطفلك 
          </p>
        </div>

        <div className="flex flex-col gap-4"> {/* Form section */}
          
          <label className="flex flex-col"> {/* Name field */}
            <span className="text-text-dark dark:text-text-light font-medium">اسم الطفل</span> 
            
            <input
              className="form-input mt-1 rounded-xl border border-border-light dark:border-border-dark p-4 text-text-dark focus:outline-none focus:ring-2 focus:ring-primary" // Input styles
              placeholder="أدخل الاسم هنا" // Placeholder
              value={childName} // State
              onChange={handleChildNameChange} // Update state
            />

            {errors.childName && <p className="error-message">{errors.childName}</p>} {/* Error message */}
          </label>

          <label className="flex flex-col"> {/* Age field */}
            <span className="text-text-dark dark:text-text-light font-medium">العمر</span> 
            
            <select
              className="form-input mt-1 rounded-xl border border-border-light dark:border-border-dark p-4 text-text-dark focus:outline-none focus:ring-2 focus:ring-primary" 
              value={childAge} // Selected age
              onChange={(e) => setChildAge(Number(e.target.value))} // Update age
            >
              <option value="4">٤ سنوات</option> 
              <option value="5">٥ سنوات</option> 
              <option value="6">٦ سنوات</option> 
            </select>
          </label>
        </div>

        {errors.general && <p className="error-message text-center">{errors.general}</p>} {/* General errors */}

        <div className="flex flex-col gap-3"> {/* Save button */}
          <button
            className="w-full py-3 bg-primary text-white font-bold rounded-full hover:opacity-90 transition-opacity" // Button style
            onClick={handleSave} // Save handler
          >
            إضافة الطفل 
          </button>
        </div>

      </div>
    </div>
  );
}

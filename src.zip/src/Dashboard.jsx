import React, { useEffect, useState } from "react"; // Import React, useEffect, and useState 
import { useLocation, useNavigate } from "react-router-dom"; // Import routing (useLocation to get state, useNavigate for navigation)
import "./Dashboard.css"; // Import the CSS styles

export default function Dashboard() { // Define the Dashboard functional component
  const location = useLocation(); // Get the location object (contains state passed during navigation)
  const navigate = useNavigate(); // Get the navigate function

  // Retrieve User Data from state or localStorage

  const [userData, setUserData] = useState(() => { // Initialize userData state
    if (location.state?.userData) { // Check if user data was passed via navigation state
      localStorage.setItem("userData", JSON.stringify(location.state.userData)); // Store in local storage
      return location.state.userData; // Return data from state
    }

    const storedUser = localStorage.getItem("userData"); // Try to get data from local storage
    return storedUser ? JSON.parse(storedUser) : null; // Return stored data or null
  });

  const [children, setChildren] = useState([]); // State to store the list of children profiles


  // Fetch Children from Server
  useEffect(() => { // Effect to fetch the list of children linked to the user
    if (!userData?.id) { // Check if user ID is missing
      navigate("/login"); // Redirect to login if user data is incomplete
      return; // Stop the effect execution
    }

    const fetchChildren = async () => { // Async function to perform the fetch operation
      try {
        const response = await fetch( // Make API call to fetch children by user ID
          `http://localhost:3001/children/${userData.id}`
        );

        const data = await response.json(); // Parse the JSON response

        const childrenData = Array.isArray(data.children) ? data.children : []; // Ensure data.children is an array

        setChildren(childrenData); // Update children state

        // Update userData state and localStorage with the fetched children list
        const updatedUser = { ...userData, children: childrenData };
        setUserData(updatedUser); // Update userData state
        localStorage.setItem("userData", JSON.stringify(updatedUser)); // Update local storage

      } catch (error) {
        console.error("Error fetching children:", error); // Log any fetch errors
      }
    };

    fetchChildren(); // Execute the fetch function
  }, [userData?.id, navigate]); // Dependencies: Re-run if userData.id or navigate changes

  if (!userData) return null; // Render nothing if userData is still null (should redirect via useEffect)

  // Delete Child Profile
  const handleDeleteChild = async (childId) => { // Async function to handle child deletion
    const confirmDelete = window.confirm("هل تريد حذف ملف الطفل؟"); // Show confirmation dialog

    if (!confirmDelete) return; // Exit if user cancels deletion

    try {
      const response = await fetch(`http://localhost:3001/children/delete/${childId}`, { // API call to delete the child
        method: "DELETE", // Use DELETE HTTP method
      });

      if (!response.ok) { // Check for non-successful response status
        alert("حدث خطأ أثناء حذف الطفل"); // Show error alert
        return;
      }

      // Remove the child from the UI state
      const updatedChildren = children.filter((child) => child.id !== childId); // Filter out the deleted child
      setChildren(updatedChildren); // Update children state

      // Update user data in state and local storage
      const updatedUser = { ...userData, children: updatedChildren };
      setUserData(updatedUser); // Update userData state
      localStorage.setItem("userData", JSON.stringify(updatedUser)); // Update local storage

    } catch (error) {
      console.error("Error deleting child:", error); // Log network or fetch errors
    }
  };

  return ( // Component JSX render
    <div className="page-container"> 
      <div className="content-box"> 

        <button className="settings-btn" onClick={() => navigate("/settings")}> {/* Settings button */}
          <span className="material-symbols-outlined">settings</span> 
        </button>

        <div className="header"> {/* Header section */}
          <div className="logo-box">
            <span className="material-symbols-outlined logo-icon">auto_awesome</span> 
            <h1 className="logo-title">أفق</h1>
          </div>

          <h2 className="title">الملف الشخصي</h2> 
          <p className="subtitle">مرحبًا بك يا {userData.firstName}</p> {/* Welcome message with first name */}
        </div>

        <h3 className="section-title">أطفالك</h3> 

        <div className="children-grid"> {/* Grid container for child cards */}
          {children.length > 0 ? ( // Conditional rendering: Check if children list is not empty
            children.map((child, idx) => ( // Map through the children array
              <div key={idx} className="child-card"> {/* Individual child profile card */}
                <div className="child-img-wrapper"> {/* Container for child image */}
                  <img
                    src={child.image || "https://i.ibb.co/3F0xXJ3/kid-avatar-1.png"} // Display child image or default avatar
                    alt={child.child_name || "Child"}
                  />
                </div>
                <p className="child-name">{child.child_name || "اسم الطفل"}</p> 

                <button
                  className="child-reports"
                    onClick={() => navigate("/home", { state: { child, userData } })} // Navigate to child's home/reports page
                >
                  عرض صفحة الطفل 
                </button>

                <button
                  className="delete-child-btn"
                  onClick={() => handleDeleteChild(child.id)} // Call delete handler
                >
                <span className="material-symbols-outlined">delete</span> {/* Delete icon */}
                </button>

              </div>
            ))
          ) : (
            <p className="no-children-msg">لم يتم إضافة أطفال بعد</p> // Message if no children are added
          )}
        </div>

        <div className="add-child-container"> 
          <button
            className="add-child-btn"
            onClick={() => navigate("/add-child", { state: { userData } })} // Navigate to Add Child form
          >
            <span className="material-symbols-outlined">add</span> {/* Add icon */}
            إضافة طفل جديد 
          </button>
        </div>
      </div>
    </div>
  );
}
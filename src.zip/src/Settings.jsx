// Settings.jsx
import React, { useState } from 'react'; // Import React and useState 
import { useNavigate } from 'react-router-dom'; // Import navigation  from React Router
import './Settings.css'; // Import CSS styles 

const ToggleSwitch = ({ isOn, handleToggle }) => { // Toggle switch component that receives on/off state and toggle handler
  return (
    <div 
      className={`switch-container ${isOn ? 'on' : 'off'}`} // Apply 'on' or 'off' class based on state
      onClick={handleToggle} // Call toggle handler on click
    >
      <div className="switch-button" /> {/* Visual button element for the switch */}
    </div>
  );
};


const SettingsItem = ({ label, iconName, onClick, isLogout = false, showArrow = true }) => { // Reusable settings item component
  const itemClasses = `settings-item ${isLogout ? 'logout-item' : ''}`; // Add logout-item class if it's a logout button
  const labelClasses = `${isLogout ? 'logout-label' : 'item-label'}`; // Apply special label styling for logout
  const iconClasses = `material-symbols-outlined main-icon ${isLogout ? 'logout-icon' : ''}`; // Apply logout icon styling if needed

  return (
    <div className={itemClasses} onClick={onClick}> {/* Container with dynamic classes and click handler */}
      <div className="item-content"> {/* Inner content wrapper */}
        <span className={iconClasses}> {/* Icon element with Material Symbols */}
          {iconName} {/* Display the icon name */}
        </span>
        <p className={labelClasses}> {/* Label text with dynamic styling */}
          {label} 
        </p>
        {showArrow && ( // Conditionally render arrow icon
          <span className="material-symbols-outlined arrow-icon"> {/* Arrow icon for navigation */}
            chevron_left  
          </span>
        )}
      </div>
    </div>
  );
};

const Settings = () => { // Main Settings component
  const navigate = useNavigate(); // Initialize navigation function
  const [isNotificationsOn, setIsNotificationsOn] = useState(true); // State for notification toggle (default: on)

  const handleNavigation = (path) => { // Function to handle navigation to different pages
   if (path === 'logout') { // Check if user is logging out
     console.log('Logging out and navigating to Home (/).'); // Log logout action
      // Navigate user to home page
     navigate('/'); // Redirect to home route
    } else { // For all other navigation paths
      console.log(`Navigating to: /${path}`); // Log navigation path
      navigate(`/${path}`); // Navigate to the specified path
    }
  };
  
  const handleToggle = (e) => { // Function to toggle notification switch
    e.stopPropagation(); // Prevent click event from bubbling up
    setIsNotificationsOn(!isNotificationsOn); // Toggle notification state
    console.log(`Notifications toggled to: ${!isNotificationsOn}`); // Log new notification state
  };

  return (
    <div className="settings-container"> {/* Main container for settings page */}
      <div className="settings-mobile-frame"> {/* Mobile frame wrapper */}
        
        <div className="header-bar"> {/* Header bar at the top */}
         <span 
              className="material-symbols-outlined back-button" 
              onClick={() => navigate('/Dashboard')} // Navigate to Dashboard on click
            >
            arrow_back 
         </span>

          <h1 className="header-title">الإعدادات</h1> 
          {/* Spacer element to balance the header layout */}
          <div className="header-spacer"></div> {/* Empty spacer for alignment */}
        </div>

        <div className="settings-scroll-content"> {/* Scrollable content area */}
          <h2 className="section-title">إدارة الحساب</h2> 
          <div className="settings-section"> {/* Account management section */}
            <SettingsItem
              label="تعديل المعلومات الشخصية" 
              iconName="person" // Person icon
              onClick={() => handleNavigation('parent-profile')} // Navigate to parent profile page
            />
            <SettingsItem
              label="تغيير كلمة المرور" 
              iconName="lock" // Lock icon
              onClick={() => handleNavigation('ForgotPassword')} // Navigate to forgot password page
            />
          </div>

          <h2 className="section-title">إعدادات التطبيق</h2> 
          <div className="settings-section"> {/* App settings section */}
            <div className="settings-item"> {/* Notifications settings item */}
              <div className="item-content"> {/* Content wrapper */}
                <span className="material-symbols-outlined main-icon"> {/* Notification icon */}
                  notifications {/* Bell icon for notifications */}
                </span>
                <p className="item-label">الإشعارات</p> 
                <ToggleSwitch isOn={isNotificationsOn} handleToggle={handleToggle} /> {/* Toggle switch for notifications */}
              </div>
            </div>

            <SettingsItem
              label="المساعدة والدعم" 
              iconName="help" // Help icon
              onClick={() => handleNavigation('help-support')} // Navigate to help and support page
            />
          </div>
          
          <div className="logout-section-wrapper"> {/* Wrapper for logout section */}
            <div className="settings-section"> {/* Logout section */}
              <SettingsItem
                label="تسجيل الخروج" 
                iconName="logout" // Logout icon
                onClick={() => handleNavigation('logout')} // Handle logout action
                isLogout={true} // Mark as logout item for special styling
                showArrow={false} // Don't show arrow for logout item
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings; // Export Settings component
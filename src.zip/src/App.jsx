import React from "react"; // import React library
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom"; // import router components
import Home from "./Home"; // import Home page
import Login from "./Login"; // import Login page
import CreateAccount from "./CreateAccount"; // import Create Account page
import Dashboard from "./Dashboard"; // import Dashboard page
import ForgotPassword from "./ForgotPassword"; // import Forgot Password page
import ResetPassword from "./ResetPassword"; // import Reset Password page
import AddChild from "./AddChild"; // import Add Child page
import ChildProfile from "./ChildProfile"; // import Child Profile page
import Settings from "./Settings"; // import Settings page
import HelpSupport from "./HelpSupport"; // import Help & Support page
import FaqDetail from "./FaqDetail"; // import FAQ Detail page
import GameManager from "./GameManager"; // import Game Manager page
import HomePage from "./HomePage"; // import Child Home page
import ParentProfile from "./ParentProfile"; // import Parent Profile page
import PerformanceRecord from "./PerformanceRecord"; // import Performance Record page

function DashboardWrapper() { // wrapper to pass user data to Dashboard
  const location = useLocation(); // get current location
  const userData = location.state?.userData || null; // extract userData from location state

  return <Dashboard userData={userData} />; // render Dashboard with user data
}

export default function App() { // main App component
  return (
    <Router> {/* wrap app with Router */}
      <Routes> {/* define all routes */}

        {/* Home page */}
        <Route path="/" element={<Home />} />

        {/* Login page */}
        <Route path="/login" element={<Login />} />

        {/* Create Account page */}
        <Route path="/register" element={<CreateAccount />} />

        {/* Dashboard page with user data */}
        <Route path="/dashboard" element={<DashboardWrapper />} />

        {/* Forgot Password page */}
        <Route path="/ForgotPassword" element={<ForgotPassword />} />

        {/* Reset Password page */}
        <Route path="/ResetPassword" element={<ResetPassword />} />

        {/* Add Child page */}
        <Route path="/add-child" element={<AddChild />} />

        {/* Child Profile page */}
        <Route path="/child-profile" element={<ChildProfile />} />

        {/* Settings page */}
        <Route path="/settings" element={<Settings />} />

        {/* Help & Support page */}
        <Route path="/help-support" element={<HelpSupport />} />

        {/* FAQ detail page with dynamic id */}
        <Route path="/faq/:id" element={<FaqDetail />} />

        {/* Game Manager page */}
        <Route path="/game" element={<GameManager />} />

        {/* Child Home page */}
        <Route path="/home" element={<HomePage />} />

        {/* Parent Profile page */}
        <Route path="/parent-profile" element={<ParentProfile />} />

        {/* Performance Record page */}
        <Route path="/performance-record" element={<PerformanceRecord />} />

      </Routes>
    </Router>
  );
}

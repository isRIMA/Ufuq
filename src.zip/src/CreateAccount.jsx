import React, { useState } from "react"; // Import React and useState
import { useNavigate } from "react-router-dom"; // Import useNavigate for navigation
import { validateCreateAccountForm } from "./ValidationFunctions"; // Import form validation function
import "./CreateAccount.css"; // Import component styles

export default function CreateAccount() { // Define the CreateAccount functional component
  const navigate = useNavigate(); // Initialize navigate function
  const [formData, setFormData] = useState({ // State for form input data
    firstName: "", // First name field
    lastName: "", // Last name field
    email: "", // Email field
    password: "", // Password field
  });
  const [showPassword, setShowPassword] = useState(false); // State to toggle password visibility
  const [errors, setErrors] = useState({}); // State to hold field-specific validation errors
  const [generalError, setGeneralError] = useState(""); // State for general server error

  // Function to update input state and clear corresponding errors on change
  const handleInputChange = (e) => {
    const { name, value } = e.target; // Destructure name and value from event target
    setFormData((prev) => ({ ...prev, [name]: value })); // Update the specific form data field

    // Clear field-specific and general errors upon input change
    if (errors[name] || generalError) {
      setErrors((prev) => ({ ...prev, [name]: "" })); // Clear field error
      setGeneralError(""); // Clear general error
    }
  };

  // Function to check password strength rules (for visual feedback)
  const isPasswordValid = (password) => {
    const minLength = password.length >= 8; // Check if length is 8 or more
    const hasUpperCase = /[A-Z]/.test(password); // Check for at least one uppercase letter
    const hasLowerCase = /[a-z]/.test(password); // Check for at least one lowercase letter
    const hasNumber = /[0-9]/.test(password); // Check for at least one number

    return { minLength, hasUpperCase, hasLowerCase, hasNumber }; // Return an object with rule status
  };

  const passwordRules = isPasswordValid(formData.password); // Get the current password rule status


  const handleCreateAccount = async () => { // Handler for the Create Account button click
    const validationErrors = validateCreateAccountForm(formData); // Run local form validation

    setErrors(validationErrors); // Update field errors state
    setGeneralError(""); // Clear previous general error

    if (Object.keys(validationErrors).length > 0) {
      return; // Stop if there are validation errors
    }

    try {
      const response = await fetch("http://localhost:3001/create-account", { // API call to create account
        method: "POST", // HTTP POST method
        headers: { "Content-Type": "application/json" }, // Set content type header
        body: JSON.stringify(formData), // Send form data as JSON body
      });

      const data = await response.json(); // Parse the JSON response

      if (response.ok) { // Check for successful response status 
        localStorage.setItem("userData", JSON.stringify(data.userData)); // Store user data in local storage
        navigate("/dashboard", { state: { userData: data.userData } }); // Navigate to dashboard
      } else {
        // Set general error message from the server
        setGeneralError(data.msg || "حدث خطأ أثناء إنشاء الحساب، يرجى المحاولة لاحقاً.");
      }
    } catch (err) {
      console.error("Error:", err); // Log network or fetch error
      setGeneralError("خطأ في الاتصال بالسيرفر، حاول مرة أخرى."); // Set network error message
    }
  };

  return ( // Component render
    <div className="page-container" dir="rtl"> {/* Main page container, set RTL direction */}

      {/* Background Circles */}
      <div className="background-circle circle-1"></div> 
      <div className="background-circle circle-2"></div> 

      <div className="content-box"> {/* Content container for form and header */}
        {/* Header Section */}
        <div className="header">
          <div className="logo-box">
            <span className="material-symbols-outlined logo-icon">group_add</span> 
            <h1 className="logo-title">أفــق</h1> 
          </div>
          <h2 className="title">إنشاء حساب جديد</h2> 
          <p className="subtitle">أهلاً بك! لنبدأ رحلة تطوير مهارات طفلك.</p>
        </div>

        {/* Registration Form Fields */}
        <div className="form-box">
          <div className="row"> {/* Container for side-by-side inputs (First/Last Name) */}
            {/* 1. First Name Input */}
            <label className="label-group">
              <p className="label">الاسم الأول</p>
              <input
                type="text"
                name="firstName" // Input name
                className="input"
                placeholder="أدخل الاسم الأول"
                value={formData.firstName}
                onChange={handleInputChange} // Handle input change
              />
              {/* Display "letters only" error if applicable  */}
              {errors.firstName && <p className="error-message">{errors.firstName}</p>} {/* Display error message */}
            </label>

            {/* 2. Last Name Input */}
            <label className="label-group">
              <p className="label">الاسم الأخير</p>
              <input
                type="text"
                name="lastName" // Input name
                className="input"
                placeholder="أدخل الاسم الأخير"
                value={formData.lastName}
                onChange={handleInputChange} // Handle input change
              />
              {/* Display "letters only" error if applicable */}
              {errors.lastName && <p className="error-message">{errors.lastName}</p>} {/* Display error message */}
            </label>
          </div>

          {/* 3. Email Input */}
          <label className="label-group">
            <p className="label">البريد الإلكتروني</p>
            <input
              type="email"
              name="email"
              className="input"
              placeholder="أدخل بريدك الإلكتروني"
              value={formData.email}
              onChange={handleInputChange}
            />
            {errors.email && <p className="error-message">{errors.email}</p>} {/* Display email error message */}
          </label>

          {/* 4. Password Input */}
          <label className="label-group">
            <p className="label">كلمة المرور</p>
            <div className="password-box"> {/* Container for password input */}
              <input
                type={showPassword ? "text" : "password"} // Toggle input type
                name="password"
                className="input"
                placeholder="أدخل كلمة المرور"
                value={formData.password}
                onChange={handleInputChange}
              />
              <span
                className="material-symbols-outlined eye-icon"
                onClick={() => setShowPassword(!showPassword)} // Toggle showPassword state
              >
                {showPassword ? "visibility" : "visibility_off"} {/* Toggle icon based on state */}
              </span>
            </div>
            {errors.password && <p className="error-message">{errors.password}</p>} {/* Display password error message */}
          </label>

          {/* Password Strength Rules */}
          <div className="password-validation-box">
            <p className="rules-heading">يجب أن تحتوي كلمة المرور على:</p> {/* Rules heading */}
            <ul> {/* List of password rules */}
              <li className={`validation-item ${passwordRules.hasLowerCase ? 'done' : ''}`}> {/* Rule: Lowercase */}
                <span className="validation-icon">{passwordRules.hasLowerCase ? '✔' : '•'}</span> {/* Status icon */}
                <span>حرف صغير واحد على الأقل (a-z)</span> 
              </li>
              <li className={`validation-item ${passwordRules.hasUpperCase ? 'done' : ''}`}> {/* Rule: Uppercase */}
                <span className="validation-icon">{passwordRules.hasUpperCase ? '✔' : '•'}</span>
                <span>حرف كبير واحد على الأقل (A-Z)</span>
              </li>
              <li className={`validation-item ${passwordRules.hasNumber ? 'done' : ''}`}> {/* Rule: Number */}
                <span className="validation-icon">{passwordRules.hasNumber ? '✔' : '•'}</span>
                <span>رقم واحد على الأقل (0-9)</span>
              </li>
              <li className={`validation-item ${passwordRules.minLength ? 'done' : ''}`}> {/* Rule: Min Length */}
                <span className="validation-icon">{passwordRules.minLength ? '✔' : '•'}</span>
                <span>8 أحرف على الأقل</span>
              </li>
            </ul>
          </div>

          {/* Display General Error */}
          {generalError && <p className="error-message text-center">{generalError}</p>}


          <button className="submit-btn" onClick={handleCreateAccount}> 
            إنشاء الحساب 
          </button>
        </div>

        {/* Login Link */}
        <div className="login-link">
          <p>
            لديك حساب بالفعل؟{" "} 
            <span
              className="link cursor-pointer"
              onClick={() => navigate("/login")} // Navigate to login page on click
            >
              تسجيل الدخول 
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
import React from "react"; // Imports the core React library
import ReactDOM from "react-dom/client"; // Imports the client-side DOM library for rendering
import App from "./App.jsx"; // Imports the main application component
import './index.css'; // Imports the global CSS styles

// Creates a root for the React application and selects the 'root' element in the HTML
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode> 
    <App />
  </React.StrictMode>
);
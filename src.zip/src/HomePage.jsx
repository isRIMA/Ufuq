import React, { useState, useEffect } from "react"; // Import React
import { useLocation, useNavigate, Link } from "react-router-dom"; // Import router and Link
import "./HomePage.css"; // Import CSS styles

export default function HomePage() { // Home page component
  const [menuOpen, setMenuOpen] = useState(false); // State to track menu open/closed
  const [lastResult, setLastResult] = useState(null); // State to store last test result

  const location = useLocation(); // Get current location from router
  const navigate = useNavigate(); // Initialize navigation function

  const child = location.state?.child; // Extract child data from location state

  useEffect(() => { // Effect to fetch last test result
    if (!child?.id) return; // Exit if no child ID

    fetch(`http://localhost:3001/get-last-result/${child.id}`) // Fetch last result from API
      .then((res) => res.json()) // Parse response as JSON
      .then((data) => { // Handle response data
        const resultData = data.result || (data.message !== "no_results" ? data : null); // Extract result or set null
        setLastResult(resultData); // Update last result state
      })
      .catch((err) => console.error(err)); // Log any errors
  }, [child]); // Re-run when child changes

  return (
    <div className="page-container"> {/* Main page container */}
      <div className="content-box"> {/* Content wrapper box */}

        {/*  Back button */}
        <div className="header-bar"> {/* Header bar container */}
          <span 
            className="material-symbols-outlined back-button" 
            onClick={() => navigate(-1)} // Navigate to previous page
          >
            arrow_back 
          </span>
        </div>

        {/*  Menu button */}
        <button className="menu-btn" onClick={() => setMenuOpen(true)}> {/* Menu toggle button */}
          <span className="material-symbols-outlined text-4xl text-gray-700">menu</span> 
        </button>

        {/*  Overlay when menu is open */}
        {menuOpen && <div className="menu-overlay" onClick={() => setMenuOpen(false)}></div>} {/* Dark overlay to close menu */}

        {/*  Side menu */}
        <div className={`side-menu ${menuOpen ? "open" : ""}`}> 
          <nav className="side-nav"> {/* Navigation container */}
            <Link // Menu item 1
              className="menu-item" // Menu item styling
              to="/child-profile" // Navigate to child profile
              state={{ child }} // Pass child data
              onClick={() => setMenuOpen(false)} // Close menu on click
            >
              <span className="material-symbols-outlined">face</span> ملف الطفل {/* Child profile icon and text */}
            </Link>

            <Link // Menu item 2
              className="menu-item" // Menu item styling
              to="/performance-record" // Navigate to performance record
              state={{ child }} // Pass child data
              onClick={() => setMenuOpen(false)} // Close menu on click
            >
              <span className="material-symbols-outlined">assessment</span> سجل الأداء {/* Performance record icon and text */}
            </Link>
          </nav>
        </div>

        {/*  Main page content */}
        <main className="header-titles"> {/* Main content section */}
          <h1 className="logo-title"> 
            <span style={{ color: "#FF7F50" }}>أُ</span>
            <span style={{ color: "#48D1CC" }}>فـ</span> 
            <span style={{ color: "#FFD700" }}>ـق</span> 
          </h1>

          <h2 className="welcome-title">مرحبًا، {child?.child_name}</h2> {/* Welcome message with child name */}

          <div className="image-box"> {/* Child image container */}
            <div // Child image
              className="image-inner" // Image styling class
              style={{ // Inline style for background image
                backgroundImage: `url("${child?.image || "https://i.ibb.co/3F0xXJ3/kid-avatar-1.png"}")`, // Child image or default avatar
              }}
            ></div>
          </div>

          <button // Start test button
            className="start-btn" // Button styling
            onClick={() => navigate("/game", { state: { child } })} // Navigate to game with child data
          >
            <span className="material-symbols-outlined text-3xl">rocket_launch</span> {/* Rocket icon */}
            ابدأ الاختبار 
          </button>
        </main>
      </div>
    </div>
  );
}
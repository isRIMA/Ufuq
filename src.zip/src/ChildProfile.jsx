import React, { useState, useEffect } from "react"; // Import React, useState, and useEffect 
import { useLocation, useNavigate } from "react-router-dom"; // Import routing from react-router-dom
import { isFieldRequired } from "./ValidationFunctions"; // Import validation function for required fields
import "./ChildProfile.css"; // Import component-specific styles

export default function ChildProfile() {
  const location = useLocation(); // To get the current location object (for passed state)
  const navigate = useNavigate(); // For programmatic navigation

  const passedChild = location.state?.child || null; // Get child data passed via navigation state
  const userData =
    location.state?.userData || JSON.parse(localStorage.getItem("userData")); // Get user (parent) data from state or local storage

  const [childId, setChildId] = useState(passedChild?.id || null); // State for child's ID, initialized from passed data
  const [childName, setChildName] = useState(passedChild?.child_name || ""); // State for child's name
  const [childAge, setChildAge] = useState(passedChild?.age || 4); // State for child's age, default 4
  const defaultAvatar =
    "https://cdn-icons-png.flaticon.com/512/456/456212.png"; // Default avatar image
  const [childImg, setChildImg] = useState(
    passedChild?.image || defaultAvatar
  ); // State for child's image, default avatar if none exists
  const [loading, setLoading] = useState(true); // State to handle loading status
  const [errors, setErrors] = useState({}); // State to store validation errors
  const [successMessage, setSuccessMessage] = useState(""); // State for success message

  useEffect(() => { // Effect to fetch child data on component load  or childId change
    if (!childId) return setLoading(false); // If no childId, stop loading immediately

    fetch(`http://localhost:3001/get-child/${childId}`) // API call to fetch child data by ID
      .then((res) => res.json()) // Parse the response as JSON
      .then((data) => {
        setChildName(data.child_name || ""); // Update child name state
        setChildAge(data.age || 4); // Update child age state
        setChildImg(data.image || defaultAvatar); // Update child image state
        setLoading(false); // Stop loading
      })
      .catch((err) => {
        console.error(err); // Log error to console
        setLoading(false); // Stop loading
        setErrors({ general: "حدث خطأ أثناء جلب بيانات الطفل" }); // Set general error message
      });
  }, [childId]); // Dependency array: run effect when childId changes

  const handleImageChange = (e) => { // Handler for child image file selection
    const file = e.target.files[0]; // Get the selected file
    if (file) {
      const reader = new FileReader(); // Create a new FileReader object
      reader.onload = () => setChildImg(reader.result); // Set childImg state to Base64 result on load
      reader.readAsDataURL(file); // Read the file as a Base64 data URL
    }
  };

  const validateChildProfile = () => { // Function to validate form inputs
    const validationErrors = {}; // Object to hold validation errors

    const nameError = isFieldRequired(childName, "اسم الطفل"); // Validate if childName is required
    if (nameError) validationErrors.childName = nameError; // Add name error if validation fails

    setErrors(validationErrors); // Update the errors state
    return Object.keys(validationErrors).length === 0; // Return true if no errors
  };

  const handleSave = async () => { // Handler for saving (Create/Update) child profile
    setSuccessMessage(""); // Clear previous success messages

    if (!validateChildProfile()) return; // Stop if validation fails

    if (!childId && !userData) { // Check for parent data when creating a new child
      setErrors({ general: "خطأ: لا يوجد بيانات للوالد لربط الطفل به." }); // Error if parent data is missing for creation
      return;
    }

    const url = childId // Determine API endpoint based on operation (Update or Create)
      ? "http://localhost:3001/update-child"
      : "http://localhost:3001/create-child";

    const method = childId ? "PUT" : "POST"; // Determine HTTP method (PUT for Update, POST for Create)

    const actionText = childId ? "تحديث" : "إنشاء"; // Operation text for success/error messages

    const bodyData = childId // Construct the request body data
      ? { childId, child_name: childName, age: childAge, image: childImg } // Data for update operation
      : {
          userId: userData.id, // Include userId for create operation
          child_name: childName,
          age: childAge,
          image: childImg,
        };

    try {
      const response = await fetch(url, { // Send the API request
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bodyData), // Convert body data to JSON string
      });

      const data = await response.json(); // Parse the response JSON

      if (response.ok) { // Check if the response status is successful 
        setSuccessMessage(`تم ${actionText} بيانات الطفل بنجاح.`); // Set success message

        // Redirect to dashboard after a short delay
        setTimeout(() => {
          navigate("/dashboard", { state: { userData } }); // Navigate to dashboard, passing user data
        }, 500);

      } else {
        setErrors({ general: data.msg || `حدث خطأ عند ${actionText}` }); // Set general error message from server or default
      }
    } catch (error) {
      setErrors({ general: "خطأ في الاتصال بالسيرفر، حاول مرة أخرى" }); // Set network error message
      console.error(error); // Log the detailed error
    }
  };

  const handleChildNameChange = (e) => { // Handler for child name input change
    setChildName(e.target.value); // Update childName state
    if (errors.childName) { // Clear name-specific error if user starts typing
      setErrors((prev) => ({ ...prev, childName: "" }));
    }
    if (successMessage) setSuccessMessage(""); // Clear success message on input change
  };

  if (loading) return <p>جاري تحميل بيانات الطفل...</p>; // Display loading text if data is being fetched

  return ( // Component JSX structure
    <div
      className="child-profile-page flex min-h-screen items-center justify-center p-4"
      dir="rtl" // Set text direction to Right-to-Left 
    >
      <div className="child-profile-card w-full max-w-md rounded-xl shadow-lg p-6 flex flex-col gap-6"> {/* Main card container */}
        <div className="flex items-center justify-between">
          <span // Back button icon
            className="material-symbols-outlined back-button"
            onClick={() => navigate(-1)} // Navigate to the previous page in history
          >
            arrow_back
          </span>
          <h2 className="text-center text-text-dark text-lg font-bold flex-1">
            ملف الطفل {/* Page Title */}
          </h2>
          <div className="w-10"></div> {/* Spacer div for alignment */}
        </div>

        <div className="flex flex-col items-center gap-4"> {/* Avatar and Image Upload section */}
          <div className="relative group"> {/* Avatar container */}
            <div // Display child's image as background
              className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-32 w-32 border-4 border-white dark:border-background-dark shadow-lg cursor-pointer"
              style={{ backgroundImage: `url(${childImg})` }} // Set image 
              onClick={() =>
                document.getElementById("childImageInput").click() // Trigger file input click on image click
              }
            ></div>

            <input // Hidden file input element
              type="file"
              id="childImageInput"
              accept="image/*" // Accept only image files
              onChange={handleImageChange} // Call handler on file selection
              style={{ display: "none" }}
            />

            <div // Edit icon button
              className="absolute bottom-0 left-0 flex items-center justify-center size-10 bg-primary rounded-full text-white cursor-pointer shadow-md group-hover:scale-110 transition-transform"
              onClick={() =>
                document.getElementById("childImageInput").click() // Trigger file input click on icon click
              }
            >
              <span className="material-symbols-outlined">edit</span>
            </div>
          </div>

          <p className="text-text-dark text-xl font-bold text-center">
            اختر صورة لطفلك {/* Choose Image */}
          </p>
        </div>

        <div className="flex flex-col gap-4"> {/* Form inputs section */}
          <label className="flex flex-col">
            <span className="text-text-dark dark:text-text-light font-medium">
              اسم الطفل {/* Label for child name */}
            </span>
            <input // Child Name input field
              className="form-input mt-1 rounded-xl border border-border-light dark:border-border-dark p-4 text-text-dark focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="أدخل الاسم هنا"
              value={childName}
              onChange={handleChildNameChange} // Handle name change
            />
            {errors.childName && ( // Display name validation error
              <p className="error-message">{errors.childName}</p>
            )}
          </label>

          <label className="flex flex-col">
            <span className="text-text-dark dark:text-text-light font-medium">
              العمر {/* Label for age select */}
            </span>
            <select // Child Age dropdown select
              className="form-select mt-1 rounded-xl border border-border-light dark:border-border-dark p-4 text-text-dark focus:outline-none focus:ring-2 focus:ring-primary"
              value={childAge}
              onChange={(e) => setChildAge(Number(e.target.value))} // Update age state
            >
              <option value="4">٤ سنوات</option>
              <option value="5">٥ سنوات</option>
              <option value="6">٦ سنوات</option>
            </select>
          </label>
        </div>

        {/* Success Message  */}
        {successMessage && (
          <p style={{ color: "green", textAlign: "center", marginTop: "10px" }}>
            {successMessage}
          </p>
        )}

        {/* General Error Message  */}
        {errors.general && (
          <p className="error-message text-center">{errors.general}</p>
        )}

        <div className="flex flex-col gap-3">
          <button // Save button
            className="w-full py-3 bg-primary text-white font-bold rounded-full hover:opacity-90 transition-opacity"
            onClick={handleSave} // Trigger save handler
          >
            حفظ التغييرات 
          </button>
        </div>
      </div>
    </div>
  );
}
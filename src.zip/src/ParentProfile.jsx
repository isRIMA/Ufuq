import React, { useState, useEffect } from "react"; // Import React and 
import { useNavigate } from "react-router-dom"; // Import navigation 
import { isFieldRequired, isValidEmail } from "./ValidationFunctions"; // Import validation functions
import "./CreateAccount.css"; // Import CSS styles

// ErrorMessage component for displaying error messages
const ErrorMessage = ({ message, style = {} }) => ( // Reusable error message component
    <p className="error-message" style={{...style }}> {/* Error message paragraph */}
      {message} {/* Display error message */}
    </p>
);


export default function ParentProfile() {
  const navigate = useNavigate(); // Initialize navigation function
  const userData = JSON.parse(localStorage.getItem("userData")); // Get user data from localStorage

  const [loading, setLoading] = useState(true); // State for loading status
  const [formData, setFormData] = useState({ // State for form data
    firstName: "", 
    lastName: "", 
    email: "" 
  });
  const [errors, setErrors] = useState({}); // State for validation errors
  const [successMessage, setSuccessMessage] = useState(''); // State for success message

  useEffect(() => { // Effect runs on component mount
    if (!userData) { // Check if user data exists
      navigate("/login"); // Redirect to login if no user data
      return; // Exit effect
    }

    fetch(`http://localhost:3001/users/${userData.id}`) // Fetch user data from API
      .then(res => res.json()) // Parse response as JSON
      .then(data => { // Handle successful response
        setFormData({ // Update form data with fetched data
          firstName: data.firstName, // Set first name
          lastName: data.lastName, // Set last name
          email: data.email // Set email
        });
        setLoading(false); // Set loading to false
      })
      .catch(err => { // Handle fetch error
        console.error("حدث خطأ أثناء جلب بيانات الأب:", err); // Log error to console
        setLoading(false); // Set loading to false
        setErrors({ general: "حدث خطأ أثناء جلب بيانات الأب" }); // Set general error message
      });
  }, []); // Empty dependency array - runs once on mount

  const handleChange = (e) => { // Function to handle input changes
    setFormData({ ...formData, [e.target.name]: e.target.value }); // Update form data with new value
    if (errors[e.target.name] || errors.general || successMessage) { // Check if errors or success message exist
        setErrors(prev => ({ ...prev, [e.target.name]: '', general: '' })); // Clear field and general errors
        setSuccessMessage(''); // Clear success message
    }
  };

  const validateParentProfile = () => { // Function to validate form data
    const validationErrors = {}; // Initialize errors object
    
    const firstNameError = isFieldRequired(formData.firstName, 'الاسم الأول'); // Validate first name
    if (firstNameError) validationErrors.firstName = firstNameError; // Add error if validation fails

    const lastNameError = isFieldRequired(formData.lastName, 'الاسم الأخير'); // Validate last name
    if (lastNameError) validationErrors.lastName = lastNameError; // Add error if validation fails

    const emailError = isValidEmail(formData.email); // Validate email
    if (emailError) validationErrors.email = emailError; // Add error if validation fails

    setErrors(validationErrors); // Update errors state
    return Object.keys(validationErrors).length === 0; // Return true if no errors
  };

  const handleSave = async () => { // Function to handle save button click
    setSuccessMessage(''); // Clear previous success message
    if (!validateParentProfile()) { // Validate form data
        return; // Stop if validation fails
    }

    try {
      const res = await fetch(`http://localhost:3001/users/${userData.id}`, { // Send PUT request to update user
        method: "PUT", // HTTP method
        headers: { "Content-Type": "application/json" }, // Set content type
        body: JSON.stringify(formData) // Convert form data to JSON
      });

      const data = await res.json(); // Parse response as JSON

      if (res.ok) { // Check if request was successful
        setSuccessMessage("تم حفظ البيانات بنجاح!"); // Set success message
        localStorage.setItem("userData", JSON.stringify({ // Update localStorage with new data
          id: userData.id, // Keep user ID
          ...formData // Spread updated form data
        }));

        setTimeout(() => { // Set timeout for navigation
          navigate("/settings", { state: { userData } }); // Navigate to settings after delay
        }, 500); // 500ms delay

      } else { // Handle unsuccessful response
        setErrors({ general: data.msg || "حدث خطأ أثناء حفظ البيانات" }); // Set error message from response or default
      }
    } catch (err) { // Handle network or server errors
      console.error(err); // Log error to console
      setErrors({ general: "حدث خطأ في الاتصال بالسيرفر، حاول مرة أخرى" }); // Set connection error message
    }
  };

  if (loading) return <p>جاري تحميل بيانات الأب...</p>; // Display loading message while fetching data

  return (
    <div className="page-container"> {/* Main container */}
      <div className="background-circle circle-1"></div> 
      <div className="background-circle circle-2"></div> 
      
      <div className="content-box"> {/* Content wrapper */}
        <div className="header parent-profile-header"> {/* Header container */}
            {/* Back button */}
            <span 
                className="material-symbols-outlined back-icon" 
                onClick={() => navigate(-1)} // Navigate back on click
            >
                arrow_back 
            </span>
          <div className="logo-box"> {/* Logo wrapper */}
            <span className="material-symbols-outlined logo-icon">auto_awesome</span> 
            <h1 className="logo-title">أفق</h1> 
          </div>
          <h2 className="title">الملف الشخصي للوالد</h2> 
          <p className="subtitle">قم بتعديل بياناتك إذا رغبت</p> 
        </div>

        <div className="form-box"> {/* Form container */}
          <label className="label-group"> {/* First name field wrapper */}
            <p className="label">الاسم الأول</p> 
            <input
              type="text" // Input type text
              name="firstName" // Input name attribute
              className="input" // CSS 
              value={formData.firstName} // Controlled input value
              onChange={handleChange} // Handle input change
            />
            {errors.firstName && <ErrorMessage message={errors.firstName} />} {/* Display first name error */}
          </label>

          <label className="label-group"> {/* Last name field wrapper */}
            <p className="label">الاسم الأخير</p> 
            <input
              type="text" // Input type text
              name="lastName" // Input name attribute
              className="input" // CSS 
              value={formData.lastName} // Controlled input value
              onChange={handleChange} // Handle input change
            />
            {errors.lastName && <ErrorMessage message={errors.lastName} />} {/* Display last name error */}
          </label>

          <label className="label-group"> {/* Email field wrapper */}
            <p className="label">البريد الإلكتروني</p> 
            <input
              type="email" // Input type email
              name="email" // Input name attribute
              className="input" // CSS 
              value={formData.email} // Controlled input value
              onChange={handleChange} // Handle input change
            />
            {errors.email && <ErrorMessage message={errors.email} />} {/* Display email error */}
          </label>
          
          {successMessage && <p style={{ color: 'green', textAlign: 'center', marginTop: '10px' }}>{successMessage}</p>} {/* Display success message */}
          
          {errors.general && <ErrorMessage message={errors.general} style={{ textAlign: 'center' }} />} {/* Display general error */}

          <button className="submit-btn" onClick={handleSave}> {/* Save button */}
            حفظ التعديلات 
          </button>
        </div>
      </div>
    </div>
  );
}
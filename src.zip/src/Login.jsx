import React, { useState } from "react"; // Import React and useState 
import { useNavigate } from "react-router-dom"; // Import navigation 
import { validateLoginForm } from "./ValidationFunctions"; // Import validation function
import "./Login.css"; // Import CSS styles

export default function Login() {
  const navigate = useNavigate(); // Initialize navigation function
  const [email, setEmail] = useState(""); // State for email input
  const [password, setPassword] = useState(""); // State for password input
  const [showPassword, setShowPassword] = useState(false); // State to toggle password visibility
  const [errors, setErrors] = useState({}); // State to store validation errors

  const handleLogin = async () => { // Function to handle login submission
    const formData = { email, password }; // Prepare form data object
    const validationErrors = validateLoginForm(formData); // Validate form inputs

    setErrors(validationErrors); // Update errors state

    if (Object.keys(validationErrors).length > 0) { // Check if there are validation errors
      return; // Stop execution if errors exist
    }

    try {
      const response = await fetch("http://localhost:3001/login", { // Send POST request to login endpoint
        method: "POST", // HTTP method
        headers: { "Content-Type": "application/json" }, // Set content type
        body: JSON.stringify(formData), // Convert form data to JSON
      });

      const data = await response.json(); // Parse response as JSON

      if (response.ok) { // Check if login was successful
        localStorage.setItem("userData", JSON.stringify(data.userData)); // Store user data in localStorage
        navigate("/dashboard", { state: { userData: data.userData } }); // Navigate to dashboard with user data
      } else {
        setErrors({ general: "البريد الإلكتروني أو كلمة المرور خاطئة." }); // Set error for invalid credentials
      }
    } catch (err) { // Handle network or server errors
      console.error("Error:", err); // Log error to console
      setErrors({ general: "خطأ في الاتصال، حاول مرة أخرى." }); // Set connection error message
    }
  };

  const handleInputChange = (e, setter, fieldName) => { // Function to handle input changes
    setter(e.target.value); // Update input value
    if (errors[fieldName] || errors.general) { // Check if field or general error exists
      setErrors(prev => ({ // Clear specific field error and general error
        ...prev, // Keep other errors
        [fieldName]: '', // Clear field error
        general: '' // Clear general error
      }));
    }
  };


  return (
    <div className="page-container" dir="rtl"> {/* Main container with RTL direction */}
      <div className="content-box"> {/* Content wrapper */}
        {/* Header section */}
        <div className="header"> {/* Header container */}
          <div className="logo-box"> {/* Logo wrapper */}
            <span className="material-symbols-outlined logo-icon">visibility</span> 
            <h1 className="logo-title">أفــق</h1> 
          </div>
          <h2 className="title">مرحبًا بعودتك!</h2> 
          <p className="subtitle">سجّل الدخول لمتابعة تقدم طفلك.</p>
        </div>

        {/* Login form section */}
        <div className="form-box"> {/* Form container */}
          <label className="label-group"> {/* Email field wrapper */}
            <p className="label">البريد الإلكتروني</p> 
            <input
              type="email" // Input type email
              className="input" // CSS 
              placeholder="أدخل بريدك الإلكتروني" // Placeholder text
              value={email} // Controlled input value
              onChange={(e) => handleInputChange(e, setEmail, 'email')} // Handle input change
            />
            {errors.email && <p className="error-message">{errors.email}</p>} {/* Display email error */}
          </label>

          <label className="label-group"> {/* Password field wrapper */}
            <p className="label">كلمة المرور</p> 
            <div className="password-box"> {/* Password input wrapper */}
              <input
                type={showPassword ? "text" : "password"} // Toggle input type based on visibility
                className="input" // CSS 
                placeholder="أدخل كلمة المرور" // Placeholder text
                value={password} // Controlled input value
                onChange={(e) => handleInputChange(e, setPassword, 'password')} // Handle input change
              />
              <span
                 className="material-symbols-outlined eye-icon" // Eye icon for toggle
                 onClick={() => setShowPassword(!showPassword)} // Toggle password visibility
              >
                 {showPassword ? "visibility" : "visibility_off"} {/* Show/hide icon based on state */}
              </span>
            </div>
            {errors.password && <p className="error-message">{errors.password}</p>} {/* Display password error */}
          </label>

          {errors.general && <p className="error-message text-center">{errors.general}</p>} {/* Display general error */}

          <span
            className="forgot-link" // Forgot password link
            onClick={() => navigate("/ForgotPassword")} // Navigate to forgot password page
          >
            نسيت كلمة المرور؟ 
          </span>

          <button className="submit-btn" onClick={handleLogin}> {/* Login button */}
            تسجيل الدخول 
          </button>
        </div>

        {/* Registration link section */}
        <div className="login-link text-center"> {/* Registration link wrapper */}
          <p> {/* Paragraph wrapper */}
            ليس لديك حساب؟{" "} 
            <span
              className="link cursor-pointer" // Clickable link
              onClick={() => navigate("/register")} // Navigate to registration page
            >
              إنشاء حساب جديد 
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
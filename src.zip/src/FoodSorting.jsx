import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react'; // Import necessary React 
import './FoodSorting.css'; // Import  CSS style

// (initialItemsData and constants remain the same) ...

const initialItemsData = [ // Array defining the initial food items
 { id: 'donut', type: 'unhealthy', emoji: '🍩', label: 'دونات (غير صحي)' }, 
 { id: 'carrot', type: 'healthy', emoji: '🥕', label: 'جزر (صحي)' }, 
 { id: 'burger', type: 'unhealthy', emoji: '🍔', label: 'برجر (غير صحي)' }, 
 { id: 'fries', type: 'unhealthy', emoji: '🍟', label: 'بطاطس (غير صحي)' }, 
 { id: 'apple', type: 'healthy', emoji: '🍎', label: 'تفاح (صحي)' }, 
 { id: 'banana', type: 'healthy', emoji: '🍌', label: 'موز (صحي)' }, 
];

const GAME_DURATION = 45; // Constant for the total game time in seconds
const INSTRUCTION_SOUND = 'FoodSorting'; // Constant for the instruction sound file name

function FoodSorting({ onComplete }) { // Functional component receiving an onComplete callback
 const [items, setItems] = useState(initialItemsData); // State for current items remaining to be sorted
 const [correctCount, setCorrectCount] = useState(0); // State for the count of correctly sorted items
 const [wrongCount, setWrongCount] = useState(0); // State for the count of incorrectly sorted items
 const [sortedItemsCount, setSortedItemsCount] = useState(0); // State for total items attempted (correct + wrong)
 
 // Adding a new status for microphone count and frequency
 const [micCount, setMicCount] = useState(0); // State to track the number of times the microphone button is clicked
 const [hesitationCount, setHesitationCount] = useState(0); // State to track dragging without dropping (hesitation/cancel)

 // Add a reference to track the projection 
 const dropOccurredRef = useRef(false); // reference to track if a successful drop occurred during a drag operation

 // Game states and countdown 
 const [gameState, setGameState] = useState('loading'); // State for the current phase of the game ('loading', 'countdown', 'active', 'completed')
 const [countdown, setCountdown] = useState(3); // State for the pre-game countdown timer
 const [timeLeft, setTimeLeft] = useState(GAME_DURATION); // State for the remaining time in the main game
 const [timerActive, setTimerActive] = useState(false); // State to control the main game timer

 const startTimeRef = useRef(Date.now()); // reference to store the start time of the 'active' game state
 const audioRef = useRef(null); // reference to store the currently playing audio element
 const totalItems = initialItemsData.length; // Total number of items in the game

    // Function to calculate the time left over (only used when time is up)
    const calculateSkipped = useCallback(() => { // Memoized function to calculate skipped items

       // The left-out question is the one that was not answered
        return totalItems - (correctCount + wrongCount); // Skipped items = Total - (Correct + Wrong)
    }, [correctCount, wrongCount, totalItems]); // Dependencies for useCallback

    //Audio Management Functions
    const stopSound = useCallback(() => { // Memoized function to stop the currently playing sound
      if (audioRef.current) { // Check if an audio element is present
          audioRef.current.pause(); // Pause the audio
          audioRef.current.currentTime = 0; // Reset playback time
          audioRef.current = null; // Clear the reference
         }
    }, []); 

  const getAudioPath = (soundName) => `/sounds/${soundName}.mp3`; // function to construct audio file path

  const playInstructionSound = useCallback(() => { // Memoized function to play the instruction sound
    stopSound(); // Stop any currently playing sound

    //Increase the microphone counter
    setMicCount(prev => prev + 1); // Increment the microphone click count
    const audio = new Audio(getAudioPath(INSTRUCTION_SOUND)); // Create a new Audio object
    audioRef.current = audio; // Store the audio object in the reference
    audio.play().catch(() => {}); // Play the audio, handling potential errors
   }, [stopSound]); // Dependency


  // Function for dealing with time running out 
  const handleTimeout = useCallback(() => { // Memoized function executed when time runs out
    setTimerActive(false); // Stop the timer
    setGameState('completed'); // Set game state to completed
    stopSound(); // Stop any sound

    const durationSeconds = GAME_DURATION; // Use the total game duration as the measured time
    // Passing the results of the mic and the left
    const skipped = calculateSkipped(); // Calculate the number of skipped items

    if (onComplete) onComplete({ // Call the onComplete callback with results
       type: 'visual', // Game type
       correct: correctCount, // Final correct count
       wrong: wrongCount, // Final wrong count
       skipped: skipped, // Skipped count
    
       drag_cancels: hesitationCount, // Hesitation/drag cancel count
       mic_clicks: micCount, // Microphone click count
       duration_seconds: durationSeconds, // Total duration
     });
  
  }, [correctCount, wrongCount, onComplete, stopSound, calculateSkipped, micCount, hesitationCount]); // Dependencies for useCallback


 // 1. Play the instructional audio during loading
 useEffect(() => { // Effect for managing the loading and instruction phase
    if (gameState === 'loading') { // Only run when in 'loading' state
      const qSound = new Audio(getAudioPath(INSTRUCTION_SOUND)); // Create audio for instructions
      audioRef.current = qSound; // Store audio in reference
      qSound.play(); // Start playing the instruction sound

      // Switch to the countdown after the instructions sound finishes
      qSound.onended = () => { // When the sound ends
          setGameState('countdown'); // Transition to 'countdown' state
          audioRef.current = null; // Clear the reference
         };
    }
 }, [gameState]); 

  // 2. Countdown management
  useEffect(() => { // Effect for managing the pre-game countdown
      if (gameState === 'countdown' && countdown > 0) { // If in countdown and time remains
          const timer = setTimeout(() => { // Set a timeout for 1 second
              setCountdown(prev => prev - 1); // Decrement countdown
             }, 1000);
          return () => clearTimeout(timer); // Cleanup function to clear timeout
         }
        else if (gameState === 'countdown' && countdown === 0) { // If countdown reaches 0
           startTimeRef.current = Date.now(); // Record the start time
           setGameState('active'); // Transition to 'active' game state
           setTimerActive(true); // Start the main timer
         }
    }, [gameState, countdown]); // Dependencies on gameState and countdown


  // 3. (Timer useEffect)
  useEffect(() => { // Effect for managing the main game timer
      if (!timerActive || timeLeft <= 0) { // Stop if timer is not active or time is up
         if (timeLeft === 0 && gameState !== 'completed') { // If time is exactly 0 and game not completed
          handleTimeout(); // Call the timeout handler
         }
      return;
    }

    const interval = setInterval(() => { // Set up a 1-second interval
        setTimeLeft((prevTime) => prevTime - 1); // Decrement time left
    }, 1000);

    return () => clearInterval(interval); // Cleanup function to clear the interval
  }, [timerActive, timeLeft, handleTimeout, gameState]); // Dependencies for the timer logic


  // 4. The natural end of the game
  useEffect(() => { // Effect for checking natural game completion (all items sorted)
       if (sortedItemsCount >= totalItems && gameState === 'active') { // If all items are sorted and game is active
       setTimerActive(false); // Stop the timer
       setGameState('completed'); // Set game state to completed
       stopSound(); // Stop any sound

       const durationSeconds = Math.round((Date.now() - startTimeRef.current) / 1000); // Calculate actual duration
       // Passing the results of the mic and the left
       const skipped = calculateSkipped(); // Calculate skipped (will be 0 here)

       if (onComplete) onComplete({ // Call onComplete callback
           type: 'visual', // Game type
           correct: correctCount, // Final correct count
           wrong: wrongCount, // Final wrong count
           skipped: 0, // Skipped is zero as all items were attempted
           drag_cancels: hesitationCount, // Hesitation count
           mic_clicks: micCount, // Microphone click count
           duration_seconds: durationSeconds, // Actual duration
          });
       }
    }, [sortedItemsCount, totalItems, onComplete, correctCount, wrongCount, gameState, stopSound, micCount, hesitationCount, calculateSkipped]); // Dependencies


  // // Drag and drop functions
  const handleDragStart = (e, id) => { // Handler for when an item starts being dragged
  if (gameState !== 'active') { // Prevent dragging if game is not active
      e.preventDefault();
      return;
     }
     e.dataTransfer.setData('text/plain', id); // Set the item ID as drag data
     e.currentTarget.classList.add('dragging'); // Add a visual class to the dragged item
     // Reset the drop status to start a new draw 
     dropOccurredRef.current = false; // Reset drop flag for the new drag operation
     setHesitationCount(prev => prev + 1); // Removed old hesitation tracking
    };

  const handleDragEnd = (e) => { // Handler for when a drag operation ends
     e.currentTarget.classList.remove('dragging'); // Remove the visual class
     // If the projection does not occur, we consider it a hesitation/cancellation process 
     if (!dropOccurredRef.current) { // If dropOccurredRef is false (no successful drop)
        setHesitationCount(prev => prev + 1); // Increment the hesitation count
     }
  };

  const allowDrop = (e) => e.preventDefault(); // Handler to allow dropping 
  const handleDragEnter = (e) => { // Handler when a dragged item enters a drop zone
     if (gameState !== 'active') return; // Only allow if game is active
     e.preventDefault();
     const bag = e.currentTarget.closest('.bag'); // Find the nearest bag element
     if (bag) bag.classList.add('bag-drop-over'); // Add a visual indicator class
  };
  const handleDragLeave = (e) => { // Handler when a dragged item leaves a drop zone
     if (gameState !== 'active') return; // Only allow if game is active
     const bag = e.currentTarget.closest('.bag'); // Find the nearest bag element
     if (bag) bag.classList.remove('bag-drop-over'); // Remove the visual indicator class
  };

  const handleDrop = (e, bagType) => { // Handler for when an item is dropped
     if (gameState !== 'active') return; // Only allow if game is active
     e.preventDefault();
     const draggedItemId = e.dataTransfer.getData('text/plain'); // Get the ID of the dragged item
     const droppedItem = initialItemsData.find(item => item.id === draggedItemId); // Find the item object
     const bag = e.currentTarget.closest('.bag'); // Find the bag element
     if (!droppedItem || !bag) return; // Exit if item or bag not found

     bag.classList.remove('bag-drop-over'); // Remove the visual indicator class

     // Recording that the projection occurred successfully
     dropOccurredRef.current = true; // Set drop flag to true

     const isCorrect = bagType === droppedItem.type; // Check if the drop is correct

     // counter update
     if (isCorrect) setCorrectCount(c => c + 1); // Increment correct count
     else setWrongCount(w => w + 1); // Increment wrong count

     const itemElement = document.getElementById(draggedItemId); // Get the DOM element of the item
     if (itemElement) {
       itemElement.style.transition = "all 0.4s ease-out"; // Apply transition for visual effect
       itemElement.style.transform = "scale(0.3)"; // Shrink the item
       itemElement.style.opacity = "0"; // Fade out the item

       setTimeout(() => { // Remove the item from state after the animation
         setItems(prev => prev.filter(item => item.id !== draggedItemId)); // Filter out the sorted item
         setSortedItemsCount(c => c + 1); // Increment the total sorted count
       }, 400); // Delay matches the CSS transition time
     }
  };

  const BagSVG = useCallback(({ labelText, type }) => { // Memoized component for the bag/refrigerator SVG
    const isHealthy = type === 'healthy'; // Check if the bag is for healthy food
    const mainColor = isHealthy ? '#22c55e' : '#ef4444'; // Define main bag color
    const strokeColor = isHealthy ? '#16a34a' : '#dc2626'; // Define stroke color
    const highlightColor = isHealthy ? '#86efac' : '#fca5a5'; // Define highlight color
    const labelTextColor = isHealthy ? 'text-green-700' : 'text-red-700'; // Define label text color

    return (
      <div
        id={`${type}Bag`} // Unique ID for the bag
        className="bag focus-ring-custom flex flex-col items-center" // Base classes for the bag
        onDragOver={allowDrop} // Allow drop
        onDrop={(e) => handleDrop(e, type)} // Handle drop event
        onDragEnter={handleDragEnter} // Handle drag entry
        onDragLeave={handleDragLeave} // Handle drag leave
        style={{}}
      >
        <svg viewBox="0 0 200 220" className="w-44 h-52"> {/* SVG container */}
          <rect x="50" y="30" width="100" height="170" fill={mainColor} stroke={strokeColor} strokeWidth="3" rx="10" ry="10" /> {/* Bag main body */}
          <rect x="135" y="80" width="8" height="30" fill={highlightColor} rx="3" ry="3" /> {/* Highlight/detail on the bag */}
        </svg>
        <span className={`text-lg font-bold mt-2 ${labelTextColor}`}>{labelText}</span> {/* Bag label text */}
      </div>
    );
  }, [gameState]); // Recreate BagSVG if gameState changes


  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 to-amber-100 flex flex-col items-center justify-start p-6 overflow-y-auto"> {/* Main container with background */}
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl p-6 flex flex-col gap-6" style={{ position: 'relative' }}> {/* Inner content box */}
        
        {/*  Display the countdown over everything else */}
        {(gameState === 'loading' || gameState === 'countdown') && ( // Conditional rendering for overlay
           <div className="countdown-display-food-match"> 
               <span className="countdown-number-food-match">
                   {gameState === 'loading' ? '' : countdown} {/* Display countdown number or empty string during loading */}
               </span>
           </div>
        )}

        <div className="w-full flex items-center justify-between mt-4"> {/* Header section container */}

  {/* Microphone button - far left */}
  <div className="flex items-center"> {/* Container for microphone button */}
    <button
      onClick={playInstructionSound} // Play instructions on click
      disabled={gameState !== 'active'} // Disable if game is not active
      className="w-12 h-12 flex items-center justify-center text-white rounded-full text-2xl shadow-lg bg-blue-600 hover:bg-blue-500 transition" // Button styling
    >
      🎙️ 
    </button>
  </div>

  <h1 className="text-3xl font-bold text-black text-center flex-1"> {/* Main title */}
    لعبة تصنيف الأطعمة
  </h1>

  {/* Timer - Far right */}
  <div className="flex justify-end"> {/* Container for the timer */}
    <div
      className={`timer-box flex items-center gap-2 px-4 py-2 rounded-xl text-xl font-bold 
      ${timeLeft <= 5 ? "timer-warning" : ""}`} // Timer styling, with warning for low time
    >
      <span>⏳</span> 
<span>{timeLeft}</span> {/* Display remaining time */}

    </div>
  </div>

</div>

        <p className="text-center text-black"> 
          اسحب الأطعمة الصحية إلى ثلاجة الطعام الصحي والأطعمة غير الصحية إلى ثلاجة الطعام الغير صحي
        </p>

        <section className="flex justify-center gap-8"> {/* Section for the drop zones (refrigerators) */}
          <BagSVG labelText="ثلاجة الطعام الصحي" type="healthy" /> {/* Healthy food bag component */}
          <BagSVG labelText="ثلاجة الطعام الغير صحي" type="unhealthy" /> {/* Unhealthy food bag component */}
        </section>

        <section className="flex flex-col items-center gap-3"> {/* Section for the draggable items */}
          <h2 className="text-lg font-semibold text-black">
            اسحب هذه العناصر: 
          </h2>

          <div className="items flex flex-wrap justify-center gap-4"> {/* Container for the items */}
            {items.map(item => ( // Map through the remaining items in state
              <button
                key={item.id} // Unique key
                id={item.id} // DOM ID for retrieval during drag/drop
                draggable={gameState === 'active'} // Only draggable when game is active
                aria-label={item.label} // Accessibility label
                onDragStart={(e) => handleDragStart(e, item.id)} // Start drag handler
                onDragEnd={handleDragEnd} // End drag handler
                className={`item w-20 h-20 flex items-center justify-center text-3xl rounded-xl border-2 border-dashed
                  ${item.type === 'healthy' ? 'border-green-500' : 'border-red-500'}
                `} // Item styling based on type
              >
                {item.emoji}
              </button>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
}

export default FoodSorting; // Export the FoodSorting component
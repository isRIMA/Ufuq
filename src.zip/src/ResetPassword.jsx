import { useState } from "react"; // Import useState 
import { useNavigate } from "react-router-dom"; // Import navigation 
import "./ResetPassword.css"; // Import CSS styles

export default function ResetPassword() {
  const [newPassword, setNewPassword] = useState(""); // State for new password input
  const [confirmPassword, setConfirmPassword] = useState(""); // State for confirm password input
  const [showNew, setShowNew] = useState(false); // State to toggle new password visibility
  const [showConfirm, setShowConfirm] = useState(false); // State to toggle confirm password visibility
  const [message, setMessage] = useState(""); // State for error/success messages
  const navigate = useNavigate(); // Initialize navigation function

  // Password validation rules
  const passwordRules = { // Object containing all password validation checks
    lowercase: /[a-z]/.test(newPassword), // Check if contains lowercase letter
    uppercase: /[A-Z]/.test(newPassword), // Check if contains uppercase letter
    number: /[0-9]/.test(newPassword), // Check if contains number
    minChar: newPassword.length >= 8, // Check if at least 8 characters
    match: newPassword === confirmPassword && newPassword !== "", // Check if passwords match and not empty
  };

  const allGood = // Check if all validation rules pass
    passwordRules.lowercase && // Lowercase check passes
    passwordRules.uppercase && // Uppercase check passes
    passwordRules.number && // Number check passes
    passwordRules.minChar && // Minimum character check passes
    passwordRules.match; // Match check passes

  // Function to get validation error messages
  const getValidationErrors = () => { // Generate array of error messages
    const errors = []; // Initialize errors array
    if (!passwordRules.lowercase) // Check lowercase rule
      errors.push("يجب أن تحتوي كلمة المرور على حرف صغير واحد على الأقل."); // Add lowercase error
    if (!passwordRules.uppercase) // Check uppercase rule
      errors.push("يجب أن تحتوي كلمة المرور على حرف كبير واحد على الأقل."); // Add uppercase error
    if (!passwordRules.number) // Check number rule
      errors.push("يجب أن تحتوي كلمة المرور على رقم واحد على الأقل."); // Add number error
    if (!passwordRules.minChar) // Check minimum character rule
      errors.push("يجب أن تكون كلمة المرور مكونة من 8 أحرف على الأقل."); // Add minimum character error
    if (!passwordRules.match) errors.push("كلمتا المرور غير متطابقتين."); // Add match error
    return errors; // Return array of errors
  };

  const handleResetPassword = async () => { // Function to handle password reset
    if (!allGood) { // Check if validation passes
      const errors = getValidationErrors(); // Get all validation errors
      setMessage(errors.join(" ")); // Display all errors in one message
      return; // Stop execution
    }

    const email = sessionStorage.getItem("email"); // Get email from session storage
    if (!email) { // Check if email exists
      setMessage("حدث خطأ: البريد الإلكتروني غير موجود"); // Set error message
      return; // Stop execution
    }

    try {
      const response = await fetch("http://localhost:3001/reset-password", { // Send POST request to reset password
        method: "POST", // HTTP method
        headers: { "Content-Type": "application/json" }, // Set content type
        body: JSON.stringify({ email, newPassword }), // Send email and new password
      });

      const data = await response.json(); // Parse response as JSON

      if (response.ok && data.success) { // Check if reset was successful
        sessionStorage.removeItem("email"); // Remove email from session storage
        setMessage("تم تغيير كلمة المرور بنجاح!"); // Set success message
        setTimeout(() => navigate("/login"), 1500); // Navigate to login after delay
        return; // Stop execution
      }

      setMessage(data.msg || "حدث خطأ غير معروف."); // Set error message from response or default
    } catch (err) { // Handle network or server errors
      setMessage("حدث خطأ أثناء الاتصال بالخادم."); // Set connection error message
    }
  };

  return (
    <div className="reset-container"> {/* Main container */}
      {/* Back arrow top-right */}
      <header className="flex items-center pt-4 pb-8"> {/* Header section */}
        <button
          className="flex items-center justify-center w-10 h-10 ml-auto" 
          onClick={() => navigate("/ForgotPassword")} // Navigate to forgot password page
        >
          <span className="material-symbols-outlined text-2xl"> {/* Arrow icon */}
            arrow_forward_ios 

          </span>
        </button>
      </header>

      <main className="flex-grow flex flex-col justify-center"> {/* Main content section */}
        <div className="text-center mb-8"> {/* Title container */}
          <h1 className="text-3xl font-bold">تعيين كلمة مرور جديدة</h1> 
          <p className="text-text-secondary mt-2">
            أدخل كلمة مرور جديدة لحسابك. 
          </p>
        </div>

        {/* New password field */}
        <div className="password-wrapper"> {/* Password input wrapper */}
          <label className="input-label">كلمة المرور الجديدة</label> 
          <div className="input-box"> {/* Input container */}
            <input
              type={showNew ? "text" : "password"} // Toggle input type based on visibility
              placeholder="أدخل كلمة المرور الجديدة" // Placeholder text
              className="password-input" // CSS 
              value={newPassword} // Controlled input value
              onChange={(e) => setNewPassword(e.target.value)} // Update state on change
            />
            <span
              className="material-symbols-outlined eye-icon" // Eye icon styling
              onClick={() => setShowNew(!showNew)} // Toggle password visibility
            >
              {showNew ? "visibility" : "visibility_off"} {/* Show/hide icon based on state */}
            </span>
          </div>
        </div>

        {/* Confirm password field */}
        <div className="password-wrapper"> {/* Confirm password wrapper */}
          <label className="input-label">تأكيد كلمة المرور الجديدة</label> 
          <div className="input-box"> {/* Input container */}
            <input
              type={showConfirm ? "text" : "password"} // Toggle input type based on visibility
              placeholder="أعد إدخال كلمة المرور" // Placeholder text
              className="password-input" // CSS 
              value={confirmPassword} // Controlled input value
              onChange={(e) => setConfirmPassword(e.target.value)} // Update state on change
            />
            <span
              className="material-symbols-outlined eye-icon" // Eye icon styling
              onClick={() => setShowConfirm(!showConfirm)} // Toggle password visibility
            >
              {showConfirm ? "visibility" : "visibility_off"} {/* Show/hide icon based on state */}
            </span>
          </div>
        </div>

        {/* Password requirements list */}
        <div className="mt-6 space-y-2"> {/* Requirements container */}
          <p className="text-sm font-medium text-text-secondary"> {/* Requirements title */}
            متطلبات كلمة المرور: 
          </p>

          <ul className="space-y-1 text-sm text-text-secondary"> {/* Requirements list */}
            <li className={`req-item ${passwordRules.lowercase ? "ok" : ""}`}> {/* Lowercase requirement with conditional styling */}
              <span className="circle"></span> حرف صغير واحد على الأقل (a-z)
            </li>

            <li className={`req-item ${passwordRules.uppercase ? "ok" : ""}`}> {/* Uppercase requirement with conditional styling */}
              <span className="circle"></span> حرف كبير واحد على الأقل (A-Z)
            </li>

            <li className={`req-item ${passwordRules.number ? "ok" : ""}`}> {/* Number requirement with conditional styling */}
              <span className="circle"></span> رقم واحد على الأقل (0-9)
            </li>

            <li className={`req-item ${passwordRules.minChar ? "ok" : ""}`}> {/* Minimum character requirement with conditional styling */}
              <span className="circle"></span> 8 أحرف على الأقل 
            </li>

            <li className={`req-item ${passwordRules.match ? "ok" : ""}`}> {/* Match requirement with conditional styling */}
              <span className="circle"></span> كلمتا المرور متطابقتان 
            </li>
          </ul>
        </div>

        {/* Error/success message display */}
        {message && <p className="error-message">{message}</p>} {/* Display message if exists */}
      </main>

      <footer className="pt-8 pb-4"> {/* Footer section */}
        <button className="reset-btn" onClick={handleResetPassword}> {/* Reset button */}
          تحديث كلمة المرور 
        </button>
      </footer>
    </div>
  );
}
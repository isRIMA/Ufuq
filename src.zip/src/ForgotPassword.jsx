import React, { useState } from "react"; // Import React and useState 
import axios from "axios"; // Import axios for HTTP requests
import { useNavigate } from "react-router-dom"; // Import useNavigate for routing
import "./ForgotPassword.css"; // Import CSS styles

export default function ForgotPassword() { // Main component definition
  const [email, setEmail] = useState(""); // State for email input
  const [message, setMessage] = useState(""); // State for feedback messages
  const navigate = useNavigate(); // Initialize navigation hook

  const validateEmail = (email) => // Email validation function
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); // Regex pattern for email format

  const handleCheckEmail = async (e) => { // Form submit handler
    e.preventDefault(); // Prevent page reload

    if (!validateEmail(email)) { // Check if email is valid
      setMessage("الرجاء إدخال بريد إلكتروني صالح"); // Set error message
      return; // Exit function
    }

    try { // Try to send request
      const res = await axios.post("http://localhost:3001/check-email", { // Send POST request
        email, // Include email in request body
      });

      if (res.status === 200) { // If email exists in database
        sessionStorage.setItem("email", email); // Store email in session
        navigate("/ResetPassword"); // Navigate to reset page
      }
    } catch (err) { // Catch any errors
      const msg = err.response?.data?.msg || "حدث خطأ أثناء التحقق من البريد"; // Extract error message
      setMessage(msg); // Display error to user
    }
  };

  return ( // Return JSX
    <div className="page-container"> {/* Main container */}
      <div className="reset-container"> {/* Form container */}
        <header className="text-center mb-20"> {/* Header section */}
          <img // Logo image
            alt="شعار" // Image alt text
            className="mx-auto mb-12 h-28 w-28 mt-32" // Logo styling
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBthuDAl0DIYnDg8pp7b7MyZugTqe0HpZD5CbJg2sVBabAPdwpKbDzdQ52kG5M_sZLqUe9hU1GDjJYLsqzDlfI23HqYDSPRDG3R1qlok3Po75GygpkpFH0GIGqdM1zH0o1Bdo_C08euDXov4U-ek4WmZK7z15nMRgNec8X_Ek-ttHzlBYk1SJdXWAj4eLr0x-xPswoQR2TA_4SVmdEBDCQIjYOsuWeDiDswpTxFNBpNbmzxz76nBTpVY8cp2vmVXhXrOVL9i005zCOy" // Logo URL
          />
          <h1 className="text-2xl font-bold text-gray-800">استرجاع كلمة المرور</h1> 
          <p className="text-gray-500 mt-2"> {/* Description text */}
            أدخل بريدك الإلكتروني للتحقق من وجود حسابك. 
          </p>
        </header>

        <main> {/* Main content section */}
          <form className="space-y-6" onSubmit={handleCheckEmail}> {/* Form with submit handler */}
            <div> {/* Input field container */}
              <label // Label for email input
                className="block text-sm font-medium text-gray-700 mb-2" // Label styling
                htmlFor="email" // Associates label with input
              >
                البريد الإلكتروني 
              </label>
              <div className="relative"> {/* Wrapper for icon positioning */}
                <span className="material-symbols-outlined icon-mail">mail</span> 
                <input // Email input field
                  id="email" // Input ID
                  name="email" // Input name
                  type="email" // Input type
                  placeholder="example@mail.com" // Placeholder text
                  required // Makes field required
                  className={`form-input pl-12 ${ // Base classes with conditional border
                    email && !validateEmail(email) ? "border-red-500" : "" // Red border if invalid
                  }`}
                  value={email} // Controlled input value
                  onChange={(e) => setEmail(e.target.value)} // Update state on change
                />
                {email && !validateEmail(email) && ( // Show error if email invalid
                  <p className="absolute text-red-500 text-sm mt-1 left-0 top-full"> {/* Error message styling */}
                    البريد الإلكتروني غير صالح 
                  </p>
                )}
              </div>
            </div>

            <div> {/* Button container */}
              <button type="submit" className="submit-btn mt-28"> 
                تحقق 
              </button>
            </div>
            {message && <p className="text-center mt-4">{message}</p>} {/* Display server message */}
          </form>
        </main>

        <footer className="mt-4 text-center"> {/* Footer section */}
          <a // Back to login link
            className="text-sm font-medium text-[#3498DB] hover:text-[#2980B9]" // Link styling with hover
            href="/login" // Link destination
          >
            العودة لتسجيل الدخول 
          </a>
        </footer>
      </div>
    </div>
  );
}
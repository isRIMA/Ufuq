import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./ForgotPassword.css";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const validateEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleCheckEmail = async (e) => {
    e.preventDefault();

    if (!validateEmail(email)) {
      setMessage("الرجاء إدخال بريد إلكتروني صالح");
      return;
    }

    try {
      const res = await axios.post("http://localhost:3001/check-email", {
        email,
      });

      // إذا الإيميل موجود — خزنه ثم انتقل إلى ResetPassword
      if (res.status === 200) {
        sessionStorage.setItem("email", email);
        navigate("/ResetPassword");
      }
    } catch (err) {
      // إذا كان الخطأ من الخادم أو الإيميل غير مسجّل
      const msg = err.response?.data?.msg || "حدث خطأ أثناء التحقق من البريد";
      setMessage(msg);
    }
  };

  return (
    <div className="page-container">
      <div className="reset-container">
        <header className="text-center mb-20">
          <img
            alt="شعار"
            className="mx-auto mb-12 h-28 w-28 mt-32"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBthuDAl0DIYnDg8pp7b7MyZugTqe0HpZD5CbJg2sVBabAPdwpKbDzdQ52kG5M_sZLqUe9hU1GDjJYLsqzDlfI23HqYDSPRDG3R1qlok3Po75GygpkpFH0GIGqdM1zH0o1Bdo_C08euDXov4U-ek4WmZK7z15nMRgNec8X_Ek-ttHzlBYk1SJdXWAj4eLr0x-xPswoQR2TA_4SVmdEBDCQIjYOsuWeDiDswpTxFNBpNbmzxz76nBTpVY8cp2vmVXhXrOVL9i005zCOy"
          />
          <h1 className="text-2xl font-bold text-gray-800">استرجاع كلمة المرور</h1>
          <p className="text-gray-500 mt-2">
            أدخل بريدك الإلكتروني للتحقق من وجود حسابك.
          </p>
        </header>

        <main>
          <form className="space-y-6" onSubmit={handleCheckEmail}>
            <div>
              <label
                className="block text-sm font-medium text-gray-700 mb-2"
                htmlFor="email"
              >
                البريد الإلكتروني
              </label>
              <div className="relative">
                <span className="material-symbols-outlined icon-mail">mail</span>
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="example@mail.com"
                  required
                  className={`form-input pl-12 ${
                    email && !validateEmail(email) ? "border-red-500" : ""
                  }`}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                {email && !validateEmail(email) && (
                  <p className="absolute text-red-500 text-sm mt-1 left-0 top-full">
                    البريد الإلكتروني غير صالح
                  </p>
                )}
              </div>
            </div>

            <div>
              <button type="submit" className="submit-btn mt-28">
                تحقق
              </button>
            </div>
            {message && <p className="text-center mt-4">{message}</p>}
          </form>
        </main>

        <footer className="mt-4 text-center">
          <a
            className="text-sm font-medium text-[#3498DB] hover:text-[#2980B9]"
            href="/login"
          >
            العودة لتسجيل الدخول
          </a>
        </footer>
      </div>
    </div>
  );
}

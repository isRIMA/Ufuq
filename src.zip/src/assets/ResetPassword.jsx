import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./ResetPassword.css";

export default function ResetPassword() {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

 // شروط كلمة المرور (تُحدّث مباشرة كل مرة المستخدم يكتب)
const getPasswordRules = (password, confirm) => {
  return {
    isLongEnough: password.length >= 8,
    hasUppercase: /[A-Z]/.test(password),
    hasNumber: /[0-9]/.test(password),
    passwordsMatch: password === confirm && password !== ""
  };
};

const { isLongEnough, hasUppercase, hasNumber, passwordsMatch } =
  getPasswordRules(newPassword, confirmPassword);


 const handleResetPassword = async () => {
  console.log("Button clicked!");

  const email = sessionStorage.getItem("email");


  if (!email) {
    setMessage("حدث خطأ: البريد الإلكتروني غير موجود");
    return;
  }

  try {
    const res = await axios.post("http://localhost:3001/reset-password", {
      email,
      newPassword,
    });

    // 👌 Now works with backend "success: true"
    if (res.data.success) {
      sessionStorage.removeItem("email");
      setMessage("تم تغيير كلمة المرور بنجاح! سيتم تحويلك الآن...");

      return;
    }

    // Server returned an error message
    setMessage(res.data.msg);

  } catch (err) {
    setMessage(err.response?.data?.msg || "حدث خطأ أثناء إعادة تعيين كلمة المرور");
  }
};

  return (
    <div className="reset-container bg-background-light dark:bg-background-dark text-text-primary dark:text-white">

      {/* زر الرجوع */}
      <header className="flex items-center pt-4 pb-8">
        <button
          className="flex items-center justify-center w-10 h-10"
          onClick={() => navigate("/ForgotPassword")}
        >
          <span className="material-symbols-outlined text-2xl">arrow_forward_ios</span>
        </button>
      </header>

      <main className="flex-grow flex flex-col justify-center">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold leading-tight tracking-tight">
            تعيين كلمة مرور جديدة
          </h1>
          <p className="text-text-secondary dark:text-gray-300 mt-2 text-base">
            أدخل كلمة مرور جديدة لحسابك.
          </p>
        </div>

        {/* كلمة المرور الجديدة */}
        <div className="password-wrapper">
          <label className="input-label">كلمة المرور الجديدة</label>
          <div className="input-box">
            <input
              type={showNew ? "text" : "password"}
              placeholder="أدخل كلمة المرور الجديدة"
              className="password-input"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
            <span
              className="material-symbols-outlined eye-icon"
              onClick={() => setShowNew(!showNew)}
            >
              {showNew ? "visibility" : "visibility_off"}
            </span>
          </div>
        </div>

        {/* تأكيد كلمة المرور */}
        <div className="password-wrapper">
          <label className="input-label">تأكيد كلمة المرور الجديدة</label>
          <div className="input-box">
            <input
              type={showConfirm ? "text" : "password"}
              placeholder="أعد إدخال كلمة المرور"
              className="password-input"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
            <span
              className="material-symbols-outlined eye-icon"
              onClick={() => setShowConfirm(!showConfirm)}
            >
              {showConfirm ? "visibility" : "visibility_off"}
            </span>
          </div>
        </div>

        {/* قائمة المتطلبات */}
        <div className="mt-6 space-y-2">
          <p className="text-sm font-medium text-text-secondary dark:text-gray-300">
            متطلبات كلمة المرور:
          </p>
         <ul className="space-y-1 text-sm text-text-secondary dark:text-gray-400">
  <li className={`req-item ${isLongEnough ? "ok" : ""}`}>
    <span className="circle"></span> 8 أحرف على الأقل 
  </li>
  <li className={`req-item ${hasUppercase ? "ok" : ""}`}>
    <span className="circle"></span> حرف كبير واحد على الأقل
  </li>
  <li className={`req-item ${hasNumber ? "ok" : ""}`}>
    <span className="circle"></span> رقم واحد على الأقل
  </li>
  <li className={`req-item ${passwordsMatch ? "ok" : ""}`}>
    <span className="circle"></span> كلمتا المرور متطابقتان
  </li>
</ul>

        </div>

        {/* رسالة الخطأ */}
        {message && <p className="text-center text-red-600 mt-4">{message}</p>}
      </main>

      {/* زر التحديث */}
      <footer className="pt-8 pb-4">
        <button
          className="reset-btn"
          disabled={!(isLongEnough && hasUppercase && hasNumber && passwordsMatch)}
          onClick={handleResetPassword}
        >
          تحديث كلمة المرور
       
        </button>
      </footer>
    </div>
  );
}

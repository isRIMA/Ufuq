import React, { useState, useEffect, useRef, useCallback } from 'react'; // Import React core features
import './ColorMatching.css'; // Import the CSS styles

// ... (initialItemsData and constants remain the same) ...
const initialItemsData = [ // Array of initial draggable items
  { id: 'cucumber', type: 'green', emoji: '🥒', label: 'عنصر أخضر: خيار' },
  { id: 'strawberry', type: 'red', emoji: '🍓', label: 'عنصر أحمر: فراولة' }, 
  { id: 'broccoli', type: 'green', emoji: '🥦', label: 'عنصر أخضر: بروكلي' },
  { id: 'tomato', type: 'red', emoji: '🍅', label: 'عنصر أحمر: طماطم' }, 
  { id: 'apple', type: 'red', emoji: '🍎', label: 'عنصر أحمر: تفاح' },
  { id: 'lettuce', type: 'green', emoji: '🥬', label: 'عنصر أخضر: خس' } 
];

const GAME_DURATION = 45; // Constant for the game time limit in seconds
const INSTRUCTION_SOUND = 'ColorMatching'; // Constant for the name of the instruction sound file

function ColorMatching({ onComplete }) { // Functional component accepting onComplete prop
  const [items, setItems] = useState(initialItemsData); // State for the current visible items
  const [correctCount, setCorrectCount] = useState(0); // State for the number of correct matches
  const [wrongCount, setWrongCount] = useState(0); // State for the number of wrong matches

  const [gameState, setGameState] = useState('loading'); // State: 'loading', 'countdown', 'active', 'completed'
  const [countdown, setCountdown] = useState(3); // State for the starting countdown timer
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION); // State for the remaining game time
  const [timerActive, setTimerActive] = useState(false); // State to control the timer interval

  // Add new state for mic clicks and hesitation count 
  const [micCount, setMicCount] = useState(0); // State to track mic (instructions) button clicks
  const [hesitationCount, setHesitationCount] = useState(0); // State to track drag cancels/hesitation

  //  Add a reference to track successful drop 
  const dropOccurredRef = useRef(false); // reference to check if a successful drop happened after DragStart

  const startTimeRef = useRef(Date.now()); // reference to store the game start timestamp
  const audioRef = useRef(null); // reference to manage the currently playing audio element

  const totalItems = initialItemsData.length; // Total number of draggable items

  //  Function to calculate skipped items 
  const calculateSkipped = useCallback(() => {
    // Skipped = Total Items - (Correct + Wrong)
    return totalItems - (correctCount + wrongCount);
  }, [correctCount, wrongCount, totalItems]); // Dependencies for memoization

  //  Function to stop the currently playing sound
  const stopSound = useCallback(() => {
    if (audioRef.current) { // Check if an audio element exists
      audioRef.current.pause(); // Pause the audio
      audioRef.current.currentTime = 0; // Reset audio time
      audioRef.current = null; // Clear the reference
    }
  }, []); // Memoize the function

  const getAudioPath = (soundName) => `/sounds/${soundName}.mp3`; // Helper to get the sound file path

  // Function to play the instruction sound
  const playInstructionSound = useCallback(() => {
    stopSound(); // Stop any existing sound
    // Increment mic click counter here 
    setMicCount(prev => prev + 1); // Increment the microphone click count
    const audio = new Audio(getAudioPath(INSTRUCTION_SOUND)); // Create new audio object
    audioRef.current = audio; // Store audio in reference
    audio.play().catch(() => {}); // Play the sound, catching potential errors
  }, [stopSound]); // Dependency includes stopSound

  // Handler for time running out (Timeout)
  const handleTimeout = useCallback(() => {
    setTimerActive(false); // Stop the timer
    setGameState('completed'); // Set game state to completed
    stopSound(); // Stop any running audio

    const durationSeconds = GAME_DURATION; // The full game duration
    // Calculate and pass mic clicks and skipped items 
    const skipped = calculateSkipped(); // Calculate skipped items

    if (onComplete) onComplete({ // Call the onComplete callback with results
      type: 'visual', // Game type
      correct: correctCount, // Correct matches count
      wrong: wrongCount, // Wrong matches count
      skipped: skipped, // Skipped items count
      drag_cancels: hesitationCount, // Drag cancels/Hesitation count
      mic_clicks: micCount, // Mic clicks count
      duration_seconds: durationSeconds, // Total duration
    });
  }, [correctCount, wrongCount, onComplete, stopSound, calculateSkipped, micCount, hesitationCount]); // Dependencies

  // 1. Play instruction sound on 'loading' state
  useEffect(() => {
    if (gameState === 'loading') { // Check if game state is loading
      const qSound = new Audio(getAudioPath(INSTRUCTION_SOUND)); // Load instruction audio
      audioRef.current = qSound; // Set audio reference
      qSound.play(); // Start playing the sound

      // Transition to countdown after sound finishes
      qSound.onended = () => {
        setGameState('countdown'); // Move to countdown state
        audioRef.current = null; // Clear audio reference
      };
    }
  }, [gameState]); // Dependency

  // 2. Manage the countdown timer (countdown)
  useEffect(() => {
    if (gameState === 'countdown' && countdown > 0) { // If counting down and timer > 0
      const timer = setTimeout(() => {
        setCountdown(prev => prev - 1); // Decrement countdown
      }, 1000);
      return () => clearTimeout(timer); // Cleanup function for the timeout
    }
    // After countdown ends
    else if (gameState === 'countdown' && countdown === 0) {
      startTimeRef.current = Date.now(); // Record the actual start time
      setGameState('active'); // Start the game
      setTimerActive(true); // Activate the game timer
    }
  }, [gameState, countdown]); // Dependencies

  // 3. Game Timer logic (Timer useEffect)
  useEffect(() => {
    if (!timerActive || timeLeft <= 0) { // If timer inactive or time runs out
      if (timeLeft === 0 && gameState !== 'completed') { // If time is 0 and game is not completed
        handleTimeout(); // Call timeout handler
      }
      return; // Stop the effect
    }

    const interval = setInterval(() => {
      setTimeLeft((prevTime) => prevTime - 1); // Decrement time every second
    }, 1000);

    return () => clearInterval(interval); // Cleanup: clear the interval
  }, [timerActive, timeLeft, handleTimeout, gameState]); // Dependencies

  // 4. Natural game completion (all items matched)
  useEffect(() => {
    if (items.length === 0 && gameState === 'active') { // If no items left and game is active
      setTimerActive(false); // Stop the timer
      setGameState('completed'); // Set game state to completed
      stopSound(); // Stop any running audio

      const durationSeconds = Math.round((Date.now() - startTimeRef.current) / 1000); // Calculate actual duration
      

      if (onComplete) { // Call onComplete with final results
        onComplete({
          type: 'visual',
          correct: correctCount,
          wrong: wrongCount,
          skipped: 0, // Skipped is always 0 on default
          drag_cancels: hesitationCount, // Drag cancels count
          mic_clicks: micCount, // Mic clicks count
          duration_seconds: durationSeconds, // Actual game duration
        });
      }
    }
  }, [items, onComplete, correctCount, wrongCount, gameState, stopSound, micCount, hesitationCount]); // Dependencies

  // Drag and Drop functions
  const handleDragStart = (e, id) => { // Handler for drag start event
    if (gameState !== 'active') { // Prevent drag if game is not active
      e.preventDefault();
      return;
    }
    e.dataTransfer.setData('text/plain', id); // Set the dragged item's ID in data transfer
    e.currentTarget.classList.add('dragging'); // Add dragging class for styling
    // Reset the drop flag for a new drag operation 
    dropOccurredRef.current = false; // Assume no drop happened yet
  };
  
  const handleDragEnd = (e) => { // Handler for drag end event (fired when drag finishes)
    e.currentTarget.classList.remove('dragging'); // Remove dragging class

    // Check if a successful drop did NOT occur
    if (!dropOccurredRef.current) {
      setHesitationCount(prev => prev + 1); // Increment hesitation counter
    }
  }; 
  const allowDrop = (e) => e.preventDefault(); // Allow element to be a drop target
  const handleDragEnter = (e) => { // Handler when dragging enters a drop target
    if (gameState !== 'active') return; // Only allow hover if game is active
    e.preventDefault();
    const bag = e.currentTarget.closest('.bag'); // Find the nearest bag container
    if (bag) bag.classList.add('bag-drop-over'); // Add hover style
  };
  const handleDragLeave = (e) => { // Handler when dragging leaves a drop target
    if (gameState !== 'active') return;
    const bag = e.currentTarget.closest('.bag');
    if (bag) bag.classList.remove('bag-drop-over'); // Remove hover style
  };

  const handleDrop = (e, bagType) => { // Handler for the drop event
    e.preventDefault();
    if (gameState !== 'active') return; // Only process drop if game is active

    const draggedItemId = e.dataTransfer.getData('text/plain'); // Get the ID of the dragged item
    const droppedItem = initialItemsData.find(item => item.id === draggedItemId); // Find the item data
    const bag = e.currentTarget.closest('.bag'); // Find the bag container
    if (!droppedItem || !bag) return; // Exit if item or bag not found

    bag.classList.remove('bag-drop-over'); // Remove hover style from bag

    // Record that a successful drop occurred
    dropOccurredRef.current = true; // Set drop occurred flag

    const isCorrect = droppedItem.type === bagType; // Check if the match is correct

    // Update the counters based on the answer
    if (isCorrect) setCorrectCount(c => c + 1); // Increment correct count
    else setWrongCount(w => w + 1); // Increment wrong count

    // hide the item
    const itemElement = document.getElementById(draggedItemId); // Get the item DOM element
    if (itemElement) {
      itemElement.style.transition = "all 0.4s ease-out"; // Set transition for smooth disappearance
      itemElement.style.transform = "scale(0.3)"; // Scale down
      itemElement.style.opacity = "0"; // Fade out

      setTimeout(() => {
        setItems(prev => prev.filter(item => item.id !== draggedItemId)); // Remove item from state after animation
      }, 400);
    }
  };


  // Bag Component (SVG)
  const BagSVG = ({ labelText, type }) => ( // Component for the drop target bags
    <div
      className="bag focus-ring-custom flex flex-col items-center"
      onDragOver={allowDrop} // Allow dropping
      onDrop={(e) => handleDrop(e, type)} // Handle successful drop
      onDragEnter={handleDragEnter} // Handle drag entering
      onDragLeave={handleDragLeave} // Handle drag leaving
      style={{}}
    >
      <svg viewBox="0 0 200 220" className="w-44 h-52"> {/* SVG container */}
        {/* SVG Path remains the same */}
        {type === 'green' ? ( // Render green bag SVG elements
          <>
            <rect x="40" y="80" width="120" height="130" fill="#22c55e" stroke="#16a34a" strokeWidth="3" />
            <path d="M40 80 L60 60 L180 60 L160 80 Z" fill="#4ade80" stroke="#16a34a" strokeWidth="2.5" />
            <path d="M160 80 L180 60 L180 190 L160 210 Z" fill="#16a34a" stroke="#15803d" strokeWidth="2.5" />
          </>
        ) : ( // Render red bag SVG elements
          <>
            <rect x="40" y="80" width="120" height="130" fill="#ef4444" stroke="#b91c1c" strokeWidth="3" />
            <path d="M40 80 L60 60 L180 60 L160 80 Z" fill="#fca5a5" stroke="#b91c1c" strokeWidth="2.5" />
            <path d="M160 80 L180 60 L180 190 L160 210 Z" fill="#dc2626" stroke="#7f1d1d" strokeWidth="2.5" />
          </>
        )}
      </svg>
      <span className={`text-lg font-bold mt-2 ${type === 'green' ? 'text-emerald-700' : 'text-red-700'}`}>
        {labelText} {/* Bag label text */}
      </span>
    </div>
  );

  return ( // Component render
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-amber-100 flex flex-col items-center justify-start p-6"> {/* Main page container */}
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl p-6 flex flex-col gap-6" style={{ position: 'relative' }}> {/* Game content area */}
  
  {/* Display countdown over everything else  */}
  {(gameState === 'loading' || gameState === 'countdown') && ( // Conditional render of countdown/loading overlay
      <div className="countdown-display-color-match">
          <span className="countdown-number">
              {gameState === 'loading' ? '' : countdown} {/* Show countdown number or nothing while loading */}
          </span>
      </div>
  )}

        {/* Title + Mic + Timer bar */}
        <div className="w-full flex items-center justify-between mt-4">

          {/* Mic Button */}
          <div className="flex items-center">
            <button
              onClick={playInstructionSound} // Play instructions on click
              disabled={gameState !== 'active'} // Disable if game is not active
              className="w-12 h-12 flex items-center justify-center text-white rounded-full text-2xl shadow-lg bg-blue-600 hover:bg-blue-500 transition"
            >
              🎙️ 
            </button>
          </div>

          {/* Title - Center */}
          <h1 className="text-3xl font-bold text-black text-center flex-1">
            لعبة تطابق الألوان 
          </h1>

          {/* Timer*/}
          <div className="flex justify-end">
            <div
              className={`timer-box flex items-center gap-2 px-4 py-2 rounded-xl text-xl font-bold 
              ${timeLeft <= 5 ? "timer-warning" : ""}`} // Add warning class if time is low
            >
              <span>⏳</span> 
              <span>{timeLeft}</span> {/* Remaining time value */}
            </div>
          </div>
        </div>

        <p className="text-center text-black">
          اسحب العناصر الحمراء إلى الصندوق الأحمر، والعناصر الخضراء إلى الصندوق الأخضر 
        </p>

        {/* The Bags (Drop Targets) */}
        <section className="flex justify-center gap-8">
          <BagSVG labelText="صندوق أخضر" type="green" /> 
          <BagSVG labelText="صندوق أحمر" type="red" /> 
        </section>

        {/* The Items (Draggable Elements) */}
        <section className="flex flex-col items-center gap-3">
          <h2 className="text-lg font-semibold text-black">
            اسحب هذه العناصر : 
          </h2>

          <div className="items flex flex-wrap justify-center gap-4"> {/* Container for draggable items */}
            {items.map((item) => ( // Map through current items state
              <button
                key={item.id} // Unique key
                id={item.id} // Element ID for reference
                draggable={gameState === 'active'} // Make draggable only when game is active
                aria-label={item.label} // Accessibility label
                onDragStart={(e) => handleDragStart(e, item.id)} // Handle drag start
                onDragEnd={handleDragEnd} // Handle drag end (for hesitation tracking)
                className={`item w-20 h-20 flex items-center justify-center text-3xl rounded-xl border-2 border-dashed
                 ${item.type === 'green' ? 'border-emerald-500' : 'border-red-500'}`} // Conditional border color
              >
                {item.emoji} {/* Display item emoji */}
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default ColorMatching; // Export the component
export const isFieldRequired = (value, fieldName) => { // Check if a field is filled (not empty)
  if (!value || value.trim() === '') { // If value is empty or only whitespace
    return `الرجاء تعبئة حقل ${fieldName}.`; // Return error message: "Please fill in the [fieldName] field"
  }
  return ''; // Return empty string if valid
};

export const isValidEmail = (email) => { // Validate email format
  // Clearer message for empty email field (previously modified) 
  if (!email || email.trim() === '') { // If email is empty or only whitespace
    return 'الرجاء إدخال بريد إلكتروني صحيح.'; // Return error: "Please enter a valid email"
  }

  // Modification: using a more comprehensive standard expression 
  // Allows letters, numbers, dots, dashes, @ symbol, and long extensions 
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Regex pattern for email validation
  if (!emailRegex.test(email)) { // If email doesn't match the pattern
    return 'أدخل عنوان بريد صحيح (يجب أن يحتوي على @).'; // Return error: "Enter a valid email (must contain @)"
  }
  return ''; // Return empty string if valid
};

export const isPasswordFilled = (password) => { // Check if password field is filled
  // Clearer message for empty password field (previously modified) 
  if (!password || password.trim() === '') { // If password is empty or only whitespace
    return 'الرجاء إدخال كلمة المرور.'; // Return error: "Please enter the password"
  }
  return ''; // Return empty string if valid
};

export const isValidCreationPassword = (password) => { // Validate password meets creation requirements
  const required = isFieldRequired(password, 'كلمة المرور'); // Check if password field is filled
  if (required) return required; // Return error if field is empty

  if (password.length < 8) { // Check if password is at least 8 characters
    return 'يجب أن تتكون كلمة المرور من 8 خانات على الأقل.'; // Return error: "Password must be at least 8 characters"
  }
  
  if (!/[A-Z]/.test(password)) { // Check if password contains at least one uppercase letter
    return 'يجب أن تحتوي كلمة المرور على حرف كبير واحد على الأقل.'; // Return error: "Password must contain at least one uppercase letter"
  }
  
  return ''; // Return empty string if valid
};

// function to verify input contains only letters (allows spaces) 
export const isValidName = (name, fieldName) => { // Validate that name contains only letters
  if (!name) return ''; // If name is empty, return empty (required check done by isFieldRequired)

  // Allows Arabic and English letters, spaces, dots, and hyphens
  const nameRegex = /^[A-Za-z\u0600-\u06FF\s.'-]+$/; // Regex for name validation (letters, Arabic, spaces, dots, hyphens)
  
  if (!nameRegex.test(name)) { // If name doesn't match the pattern
    return `${fieldName} يجب أن يحتوي على حروف فقط.`; // Return error: "[fieldName] must contain only letters"
  }
  return ''; // Return empty string if valid
}

export const validateLoginForm = (data) => { // Validate login form data
    const errors = {}; // Object to store validation errors
    
    const emailError = isValidEmail(data.email); // Validate email field
    if (emailError) errors.email = emailError; // Add email error if exists

    const passwordError = isPasswordFilled(data.password); // Validate password field is filled
    if (passwordError) errors.password = passwordError; // Add password error if exists

    return errors; // Return errors object
};

export const validateCreateAccountForm = (data) => { // Validate account creation form data
    const errors = {}; // Object to store validation errors

    // 1. First name 
    const firstNameRequiredError = isFieldRequired(data.firstName, 'الاسم الأول'); // Check if first name is filled
    if (firstNameRequiredError) { // If first name is empty
      errors.firstName = firstNameRequiredError; // Add required error
    } else { // If first name is filled
      const firstNameNameError = isValidName(data.firstName, 'الاسم الأول'); // Validate first name format
      if (firstNameNameError) errors.firstName = firstNameNameError; // Add format error if exists
    }


    // 2. Last name (family name) 
    const lastNameRequiredError = isFieldRequired(data.lastName, 'الاسم الأخير'); // Check if last name is filled
    if (lastNameRequiredError) { // If last name is empty
      errors.lastName = lastNameRequiredError; // Add required error
    } else { // If last name is filled
      const lastNameNameError = isValidName(data.lastName, 'الاسم الأخير'); // Validate last name format
      if (lastNameNameError) errors.lastName = lastNameNameError; // Add format error if exists
    }

    // 3. Email 
    const emailError = isValidEmail(data.email); // Validate email format
    if (emailError) errors.email = emailError; // Add email error if exists

    // 4. Password 
    const passwordError = isValidCreationPassword(data.password); // Validate password meets requirements
    if (passwordError) errors.password = passwordError; // Add password error if exists
    
    return errors; // Return errors object
};
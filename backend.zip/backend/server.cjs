// ================== Import ==================
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const cors = require("cors");

const app = express();

// ================== Basic settings ==================
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// ================== communication MySQL ==================
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "ofoq",
  port: 8889,
  multipleStatements: false,
});

db.connect((err) => {
  if (err) console.error("DB connection error:", err);
  else console.log("Connected to MySQL");
});

// ================== Create an account ==================
app.post("/create-account", async (req, res) => {
  const { firstName, lastName, email, password } = req.body;

  if (!firstName || !lastName || !email || !password)
   return res.status(400).json({ msg: "All fields are required." });

  try {
   const hashedPassword = await bcrypt.hash(password, 10);

    const query = `
     INSERT INTO users (firstName, lastName, email, password)
     VALUES (?, ?, ?, ?)
     `.trim();
      db.query(
        query,
        [firstName, lastName, email, hashedPassword],
        (err, result) => {
        if (err) {
          if (err.code === "ER_DUP_ENTRY")
            return res.status(400).json({ msg: "Email already registered." });

          console.error("DB Error:", err);
          return res.status(500).json({ msg: "Database error", error: err });
        }

        return res.status(200).json({
          msg: "Account created successfully!",
          userData: {
             id: result.insertId,
             firstName,
             lastName,
             email,
          }
        });
      }
    );
  } catch (error) {
    return res.status(500).json({ msg: "Server error", error });
  }
});

// ================== Login ==================
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ msg: "All fields are required." });

  db.query(
    "SELECT * FROM users WHERE email = ?",
    [email],
    async (err, results) => {
      if (err) return res.status(500).json({ msg: "Database error", error: err });
      if (results.length === 0)
         return res.status(400).json({ msg: "Email not found." });

      const user = results[0];
      const match = await bcrypt.compare(password, user.password);

      if (!match) return res.status(400).json({ msg: "Incorrect password." });

      return res.status(200).json({
          msg: "Login successful!",
          userData: {
          id: user.id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
        },
      });
   }
  );
});

// ================== Retrieve user data ==================
app.get("/users/:id", (req, res) => {
  const userId = req.params.id;

  const sql = "SELECT id, firstName, lastName, email FROM users WHERE id = ?";
  db.query(sql, [userId], (err, results) => {
    if (err) {
      console.error("DB Error:", err);
      return res.status(500).json({ msg: "Database error", error: err });
    }

    if (results.length === 0) {
      return res.status(404).json({ msg: "User not found" });
    }

    return res.status(200).json(results[0]);
  });
});

// ================== Update user data ==================
app.put("/users/:id", (req, res) => {
  const userId = req.params.id;
  const { firstName, lastName, email } = req.body;

  if (!firstName || !lastName || !email) {
    return res.status(400).json({ msg: "جميع الحقول مطلوبة" });
  }

  const sql = `
    UPDATE users 
    SET firstName = ?, lastName = ?, email = ?
    WHERE id = ?
  `;

  db.query(sql, [firstName, lastName, email, userId], (err, result) => {
    if (err) {
      console.error("DB Update Error:", err);
      
      if (err.code === "ER_DUP_ENTRY") {
        return res.status(400).json({ msg: "الإيميل مستخدم مسبقًا" });
      }

      return res.status(500).json({ msg: "Database error", error: err });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ msg: "المستخدم غير موجود" });
    }

    return res.status(200).json({ msg: "تم تحديث البيانات بنجاح" });
  });
});

// ================== Add a child ==================
app.post("/add-child", (req, res) => {
  const { parentId, child_name, age, image } = req.body;

  if (!parentId || !child_name || !age)
   return res.status(400).json({ msg: "All fields required." });

  const sql = `
    INSERT INTO children (parent_id, child_name, age, image)
    VALUES (?, ?, ?, ?)
   `.trim();

  db.query(sql, [parentId, child_name, age, image], (err, result) => {
    if (err) {
      console.error("DB Error:", err);
      return res.status(500).json({ msg: "DB error", error: err });
    }

    res.status(200).json({
      msg: "Child added successfully",
       child: {
       id: result.insertId,
       child_name,
       age,
       image,
      },
    });
  });
});

// ================== Update child ==================
app.put("/update-child", (req, res) => {
  const { childId, child_name, age, image } = req.body;

  if (!childId || !child_name || !age)
    return res.status(400).json({ msg: "All fields required." });

  const sql = `
    UPDATE children 
    SET child_name = ?, age = ?, image = ?
    WHERE id = ?
  `.trim();

  db.query(sql, [child_name, age, image, childId], (err) => {
    if (err) {
     console.error("DB Error:", err);
     return res.status(500).json({ msg: "DB error", error: err });
    }

   res.status(200).json({ msg: "Child updated successfully" });
  });
});

// ================== Retrieve user's children ==================
app.get("/children/:parent_id", (req, res) => {
  const parent_id = req.params.parent_id;

  db.query(
   "SELECT * FROM children WHERE parent_id = ?",
   [parent_id],
   (err, results) => {
     if (err) return res.status(500).json({ msg: "DB error", error: err });
     res.status(200).json({ children: results });
    }
  );
});

// ================== Retrieve one child ==================
app.get("/get-child/:child_id", (req, res) => {
  const id = req.params.child_id;

  db.query("SELECT * FROM children WHERE id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ msg: "DB error", error: err });

    if (results.length === 0)
     return res.status(404).json({ msg: "Child not found" });

    res.status(200).json(results[0]);
  });
});

// ================== Save test result ==================
app.post("/save-test-result", (req, res) => {
  const {
    child_id,
    visual,
    audio,
    dominant, 
    total_correct,
    total_wrong,
    duration_seconds,
    total_skipped, 
    mic_clicks, 
    drag_cancels,
  } = req.body;
  

  const sql = `
    INSERT INTO test_results 
    (child_id, visual, audio, dominant, total_correct, total_wrong, duration_seconds, total_skipped, total_mic_clicks, total_drag_cancels)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `.trim();

  db.query(
    sql,
    [
      child_id,
      visual,
      audio,
      dominant || 'mixed', 
      total_correct,
      total_wrong,
      duration_seconds,
      total_skipped || 0, 
      mic_clicks || 0,
      drag_cancels || 0,
    ],
    (err, result) => {
      if (err) {
        console.error(" DB Error:", err);
        return res.status(500).json({ error: "Database error" });
      }

      res.json({ 
        success: true, 
        message: "Result saved successfully",
        id: result.insertId 
      });
    }
  );
});

// ================== Retrieve latest result ==================
app.get("/get-last-result/:childId", (req, res) => {
  const childId = req.params.childId;

  const sql = `
   SELECT * FROM test_results
   WHERE child_id = ?
   ORDER BY id DESC
   LIMIT 1
  `.trim();
 
  db.query(sql, [childId], (err, rows) => {
   if (err) {
     console.error("DB Error:", err);
     return res.status(500).json({ error: "Database error" });
    }

    if (rows.length === 0)
      return res.json({ message: "No results found", result: null });

    res.json({ result: rows[0] });
  });
});

// ================== Save details of a single game ==================
app.post("/save-game-detail", (req, res) => {
  const {
    test_result_id, 
    game_name,
    correct_answers,
    wrong_answers,
    skipped_answers,
    duration_seconds,
    mic_clicks, 
    drag_cancels, 
  } = req.body;
  
  if (!test_result_id) {
     console.error("Error: test_result_id is missing in request body.");
     return res.status(400).json({ msg: "Missing test_result_id." });
  }

  const sql = `
    INSERT INTO game_details (
      test_result_id, game_name, correct_answers, wrong_answers, 
      skipped_answers, duration_seconds, mic_clicks, drag_cancels
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    test_result_id, game_name, correct_answers, wrong_answers,
    skipped_answers, duration_seconds, mic_clicks || 0, drag_cancels || 0, 
  ];

  db.query(sql, values, (err, result) => {
    if (err) {
      console.error("DB insert game detail error:", err);
      return res.status(500).json({ msg: "Database error", error: err.message });
    }
    console.log("Game detail saved:", result.insertId);
    res.status(201).json({ msg: "Game detail saved successfully", id: result.insertId });
  });
});

// ================== Retrieve all the results of one child ==================
app.get("/performance-records/:childId", (req, res) => {
  const childId = req.params.childId;

  const sql = `
    SELECT 
      id,
      visual,
      audio,
      dominant,
      total_correct,
      total_wrong,
      duration_seconds,
      created_at
    FROM test_results
    WHERE child_id = ?
    ORDER BY id DESC
  `.trim();

  db.query(sql, [childId], (err, rows) => {
    if (err) {
      console.error("DB Error:", err);
      return res.status(500).json({ error: "Database error" });
    }

    res.json({ records: rows });
  });
});


// ================== Delete child ==================
app.delete("/children/delete/:child_id", (req, res) => {
  const child_id = req.params.child_id;

  const sql = "DELETE FROM children WHERE id = ?";

  db.query(sql, [child_id], (err, result) => {
    if (err) {
      console.error("DB delete error:", err);
      return res.status(500).json({ msg: "Database error", error: err });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ msg: "Child not found" });
    }

    return res.status(200).json({ msg: "Child deleted successfully" });
  });
});

app.post("/check-email", (req, res) => {
 const { email } = req.body;
 if (!email) {
    return res.status(400).json({ msg: "الإيميل مطلوب" });
  }

  const sql = "SELECT id FROM users WHERE email = ?";
  db.query(sql, [email], (err, results) => {
    if (err) {
      console.error("خطأ في الاستعلام:", err);
      return res.status(500).json({ msg: "خطأ في الخادم" });
    }

    if (results.length === 0) {
      return res.status(404).json({ msg: "الإيميل غير مسجّل" });
    }

    return res.status(200).json({ msg: "الإيميل موجود" });
  });
});

app.post("/reset-password", async (req, res) => {
 const { email, newPassword } = req.body;
 if (!email || !newPassword) {
   return res.status(400).json({ msg: "الإيميل وكلمة المرور الجديدة مطلوبان" });
  }
  const hashed = await bcrypt.hash(newPassword, 10);

  const sql = "UPDATE users SET password = ? WHERE email = ?";
  db.query(sql, [hashed, email], (err, result) => {
    if (err) {
      console.error("خطأ في تحديث كلمة المرور:", err);
      return res.status(500).json({ msg: "خطأ في الخادم" });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ msg: "البريد الإلكتروني غير موجود" });
    }
  return res.status(200).json({ success: true, msg: "تم إعادة تعيين كلمة المرور بنجاح" });
  });
});

// ================== Server startup ==================
app.listen(3001, () => {
  console.log(" Server running on http://localhost:3001");
});